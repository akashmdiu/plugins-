<?php

namespace PoliticalElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */


class PoliticalAccordion extends Widget_Base
{

    public function get_name()
    {
        return 'political-accordion';
    }

    public function get_title()
    {
        return __('Political Accordion', 'political-core');
    }

    public function get_icon()
    {
        return 'eicon-accordion';
    }

    public function get_categories()
    {
        return ['political-addons'];
    }
    protected function _register_controls()
    {

        $this->start_controls_section(
            'accordion_content',
            [
                'label' => __('Accordion Content', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'accordion_title',
            [
                'label' => __('Title', 'political-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Why should i buy that template?', 'political-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'accordion_content',
            [
                'label' => __('Content', 'political-core'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.', 'political-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'accordion_list',
            [
                'label' => __('Accordion List', 'political-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'accordion_title' => __('Why should i buy that template?', 'political-core'),
                        'accordion_content' => __('Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.', 'political-core'),
                    ],
                    [
                        'accordion_title' => __('Do you have any example of checkout page?', 'political-core'),
                        'accordion_content' => __('Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.', 'political-core'),
                    ],
                ],
                'title_field' => '{{{ accordion_title }}}',
            ]
        );

        $this->add_control(
            'accordion_icon',
            [
                'label' => __('Icon', 'political-core'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-plus',
                    'library' => 'fa-solid',
                ],
                'label_block' => true
            ]
        );
        $this->add_control(
            'accordion_active_icon',
            [
                'label' => __('Active Icon', 'political-core'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-minus',
                    'library' => 'fa-solid',
                ],
                'label_block' => true
            ]
        );


        $this->end_controls_section();

        

		$this->start_controls_section(
			'p_section_toggle_style_title',
			[
				'label' => __( 'Title', 'political-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'p_title_color',
			[
				'label' => __( 'color', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-header button.collapsed' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'tab_active_color',
			[
				'label' => __( 'Active Color', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-header button' => 'color: {{VALUE}};',
				],
			]
		);

        
		$this->add_control(
			'p_title_background',
			[
				'label' => __( 'Background', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-header button.collapsed' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'p_title_active_background',
			[
				'label' => __( 'Active Background', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-header button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'p_title_typography',
				'selector' => '{{WRAPPER}} .faq-accordion .card .card-header button',
			]
		);

		$this->add_responsive_control(
			'p_title_padding',
			[
				'label' => __( 'Padding', 'political-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-header button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();


		$this->start_controls_section(
			'p_section_toggle_style_content',
			[
				'label' => __( 'Content', 'political-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'p_content_color',
			[
				'label' => __( 'color', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-body' => 'color: {{VALUE}};',
				],
			]
		);


        
		$this->add_control(
			'p_content_background',
			[
				'label' => __( 'Background', 'political-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-body' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'p_content_typography',
				'selector' => '{{WRAPPER}} .faq-accordion .card .card-body',
			]
		);

		$this->add_responsive_control(
			'p_content_padding',
			[
				'label' => __( 'Padding', 'political-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .card .card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);



        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        
        $x = 0;
        echo '<div class="faq-accordion" id="accordion">';
        foreach ($settings['accordion_list'] as $item) {
            $x++;
            echo '<div class="card">
                <div class="card-header" id="heading'.$x.'">
                    <button data-bs-toggle="collapse" data-bs-target="#collapse'.$x.'" aria-expanded="false" aria-controls="collapse'.$x.'" class="collapsed">
                        '.$item['accordion_title'].'
                        <span class="accordion-icon-collapse"> <i class="'. $settings['accordion_icon']['value'].'"> </i></span>
                        <span class="accordion-icon-active "> <i class="'. $settings['accordion_active_icon']['value'].'"> </i></span>
                    </button>
                </div>

                <div id="collapse'.$x.'" class="collapse" aria-labelledby="heading'.$x.'" data-parent="#accordion" style="">
                    <div class="card-body">
                        '.$item['accordion_content'].'
                    </div>
                </div>
            </div>';
        }
        echo '</div>';

    }
}
