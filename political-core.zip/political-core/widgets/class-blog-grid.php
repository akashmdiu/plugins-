<?php

namespace PoliticalElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */

function post_categories(){
	    
    $terms = get_terms( array(
        'taxonomy' => 'category',
        'hide_empty' => false,
    ) );
    
    $term_name = wp_list_pluck( $terms, 'name', 'term_id');
    
    return $term_name;
    
}

function get_p_post_type(){
$p_post_type = get_post_types(
	array(
		'_builtin' => true,
		'public' => true
	),
);
return $p_post_type;
}

class PoliticalBlogGrid extends Widget_Base
{

    public function get_name()
    {
        return 'blog-grid';
    }

    public function get_title()
    {
        return __('Blog Grid', 'political-core');
    }

    public function get_icon()
    {
        return 'eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['political-addons'];
    }
    protected function _register_controls()
    {

        $this->start_controls_section(
            'p_blog_query',
            [
                'label' => esc_html__('Query', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'p_post_type',
            [
                'label' => esc_html__('Post Type', 'political-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => get_p_post_type(),
                'label_block' => true
            ]
        );
        $this->add_control(
            'post_category',
            [
                'label' => esc_html__('Categories', 'political-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => post_categories(),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post_order',
            [
                'label' => esc_html__('Order', 'political-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'ASC'  => esc_html__('ASC', 'political-core'),
                    'DSC' => esc_html__('DSC', 'political-core'),
                ],
                'default' => esc_html__('DSC', 'political-core'),
            ]
        );
        $this->add_control(
            'post_order_by',
            [
                'label' => esc_html__('Order By', 'political-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'title'  => esc_html__('Title', 'political-core'),
                    'name' => esc_html__('Name', 'political-core'),
                    'id' => esc_html__('ID', 'political-core'),
                    'date' => esc_html__('Date', 'political-core'),
                ],
                'default' => esc_html__('title', 'political-core'),
            ]
        );
        
        $this->add_control(
            'title_words_limit',
            [
                'label' => esc_html__('Title Words Limit', 'political-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__('8', 'political-core'),
            ]
        );

        $this->add_control(
            'p_post_excerpt_limit',
            [
                'label' => esc_html__('Post Excerpt Limit', 'political-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__('30', 'political-core'),
            ]
        );

        $this->add_control(
            'post_per_page',
            [
                'label' => esc_html__('Post Per Page', 'political-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('6', 'political-core'),
                'placeholder' => esc_html__('Input post per page', 'political-core'),
            ]
        );
        

        $this->end_controls_section();

        $this->start_controls_section(
            'p_blog_options',
            [
                'label' => esc_html__('Options', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
			'p_post_per_row',
			[
				'label' => __( 'Post Per Row', 'political' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'6'  => __( '2', 'political' ),
					'4' => __( '3', 'political' ),
					'3' => __( '4', 'political' ),
					'2' => __( '6', 'political' ),
				],
			]
		);

        $this->add_control(
            'p_post_meta',
            [
                'label' => esc_html__('Post Meta', 'political-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'political-core'),
                'label_off' => esc_html__('Hide', 'political-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'p_post_readmore',
            [
                'label' => esc_html__('Post Readmore', 'political-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'political-core'),
                'label_off' => esc_html__('Hide', 'political-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'post_pagination',
            [
                'label' => esc_html__('Pagination', 'political-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'political-core'),
                'label_off' => esc_html__('Hide', 'political-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
			'p_pagination_align',
			[
				'label' => esc_html__( 'Pagination Alignment', 'political' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'political' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'political' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'political' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
			]
		);



        $this->end_controls_section();


        //Style Tab
        $this->start_controls_section(
            'post_style',
            [
                'label' => esc_html__('Style', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'p_blog_title',
			[
				'label' => __( 'Title', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_blog_title_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-content h4 a' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_title_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .news-content h4 a',
			]
		);
        $this->add_control(
			'p_blog_meta_data',
			[
				'label' => __( 'Meta Data', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_blog_metadata_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-post .news-content .meta-data li small' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'p_blog_metadata_bg_color',
			[
				'label' => __( 'Background Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-post .news-content .meta-data li' => 'background-color: {{VALUE}}!important',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_metadata_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .news-post .news-content .meta-data li small',
			]
		);


        //Excerpt Style
        $this->add_control(
			'p_blog_excerpt',
			[
				'label' => __( 'Post Excerpt', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_blog_excerpt_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-content .post-excerpt' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_excerpt_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .news-content .post-excerpt',
			]
		);

        //Readmore Style
        $this->add_control(
			'p_blog_readmore',
			[
				'label' => __( 'Post Readmore', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_blog_readmore_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-content .read-more-btn' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_readmore_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .news-content .read-more-btn',
			]
		);

        //Pagination style 
        $this->add_control(
            'post_title_style',
            [
                'label' => esc_html__('Pagination', 'political-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'p_pagination_color',
            [
                'label' => esc_html__('Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_current_color',
            [
                'label' => esc_html__('Current Page Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_bg_color',
            [
                'label' => esc_html__('Background Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_bg_current__color',
            [
                'label' => esc_html__('Background Current Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'p_pagination_typography',
                'label' => esc_html__('Typography', 'political-core'),
                'selector' => '{{WRAPPER}} .pagination .nav-links .page-numbers',
            ]
        );
        

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display(); ?>



        <div class="row blog-grid">
            <?php
                    //$x = 0;
                    $posts_per_page = $settings['post_per_page'];
                    $order = $settings['post_order'];
                    // $post_style = $settings['blog_style'];
                    // $layout1 = $settings['style_one_layout'];
                    // $layout2 = $settings['style_two_layout'];
                    $words_limit = $settings['title_words_limit'];
                    $posts_per_row = $settings['p_post_per_row'];
                    $posts_type = $settings['p_post_type'];
                    $posts_meta = $settings['p_post_meta'];

                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    if (is_front_page()) {
                        $paged = (get_query_var('page')) ? get_query_var('page') : 1;
                    }


                    $query = new \WP_Query(array(
                        'post_type' =>  $posts_type,
                        'posts_per_page' => $posts_per_page,
                        'order' => "$order",
                        'post_status' => 'publish',
                        'category__in' => $settings['post_category'],
                        'paged' => $paged

                    ));
                    if ($query->have_posts()) :
                        while ($query->have_posts()) : $query->the_post(); ?>
                        <div class="col-md-6 col-lg-<?php echo esc_html( $posts_per_row ); ?>">
                            <div class="news-post">

                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="feature-image">
                                        <div class="image-frame">
                                            <a href="<?php the_permalink(); ?>">
                                                <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title(); ?>" class="w-100">
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="news-content">
                                    <h4><a href="<?php the_permalink(); ?>">
                                    <?php echo wp_trim_words( get_the_title(), $words_limit ); ?>
                                </a></h4>

                                    <?php if( $posts_meta == 'yes'): ?>
                                        <ul class="meta-data list-inline">
                                            <li class="list-inline-item badge bg-danger"><small> <?php echo esc_html(political_post_time_ago()); ?></small></li>
                                        </ul>
                                    <?php endif; ?>

                                    <p class="post-excerpt">
                                        <?php
                                            if (function_exists('political_excerpt')) :
                                                echo political_excerpt();
                                            else:
                                                the_excerpt();
                                            endif;
                                        ?>
                                    </p>
                                    
                                    <?php if($settings['p_post_readmore']): ?>
                                        <a href="<?php the_permalink(); ?>" class="read-more-btn"><?php echo esc_html__('Read More', 'political'); ?><i class="im im-angle-right"></i></a>
                                    <?php endif; ?>

                                </div>
                            </div>

                        </div>

                <?php endwhile;

                $total_pages = $query->max_num_pages;
                $current_page = max(1, get_query_var('paged'));

                if (is_front_page()) :
                    $current_page = max(1, get_query_var('page'));
                endif;
            endif; ?>

        </div>

<?php if ($settings['post_pagination'] == 'yes') :
        echo '<div class="row pagination" style="text-align: '.$settings['p_pagination_align'].'!important"> <div class="nav-links col-md-12">';
            echo paginate_links(array(
                'total' => $total_pages,
                'current' => $current_page,
                'prev_text'    => esc_html__('prev'),
                'next_text'    => esc_html__('next'),
            ));
        echo '<div></div>';
        endif;
    }
}
