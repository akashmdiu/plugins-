<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostPriceTable3 extends Widget_Base {

	public function get_name() {
		return 'price-table3';
	}

	public function get_title() {
		return __( 'Price Table3', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-money';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'title_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
           
            
            $this->add_control(
                'pricing_name',
                [
                    'label' => __( 'Pricing Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Basic', 'axiohost-elementor-addons' ),
                ]
            );  
            $this->add_control(
                'for_package',
                [
                    'label' => __( 'For', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'For Individual Wevsite', 'axiohost-elementor-addons' ),
                ]
            );  
            $this->add_control(
                'price',
                [
                    'label' => __( 'Price', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '00', 'axiohost-elementor-addons' ),
                ]
            );  
            $this->add_control(
                'payment_duration',
                [
                    'label' => __( 'Payment Duration', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'monthly',
                    'options' => [
                        'monthly'  => __( 'Monthly', 'axiohost-elementor-addons' ),
                        'yearly' => __( 'Yearly', 'axiohost-elementor-addons' ),
                    ],
                ]
            ); 
            $repeater = new \Elementor\Repeater();
            $repeater->add_control(
                'pricing_plan',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => '13 GB storage',
                ]
            );
            $this->add_control(
                'plan_list',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'pricing_plan' => __( 'Pricing Plan #1', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'pricing_plan' => __( 'Pricing Plan #2', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{pricing_plan}}}',
                ]
            );

            $this->add_control(
                'pricing_button',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_label',
                [
                    'label' => __( 'Button Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Buy Now', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'price_table2_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'table_background',
                [
                    'label' => __( 'Table Background', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-plan-box2' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'pricing_name_style',
                [
                    'label' => __( 'Pricing Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'pricing_name_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing_name' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'hosting_name_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing_name',
                ]
            );
            

            $this->add_control(
                'pricing_style',
                [
                    'label' => __( 'Pricing', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'pricing_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-big' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'pricing_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-big',
                ]
            );

            $this->add_control(
                'pricing_duration_style',
                [
                    'label' => __( 'Payment Duration', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
           
            
            $this->add_control(
                'duration_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-small' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'duration_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-small',
                ]
            );
            
            $this->add_control(
                'plan_style',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'plan_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .price-plan' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'plan_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .price-plan',
                ]
            );

            $this->add_control(
                'button_style',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'button_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-btn',
                ]
            );
            $this->add_control(
                'button_bgcolor',
                [
                    'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'button_border_color',
                [
                    'label' => __( 'Border Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'border-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'hover_button_bgcolor',
                [
                    'label' => __( 'Hover Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn:hover' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                '_hover_button_border_color',
                [
                    'label' => __( 'Hover Border Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn:hover' => 'border-color: {{VALUE}}',
                    ],
                ]
            );


        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $plan_list = $settings['plan_list'];?>
         <div class="pricing-plan-box2 wow fadeIn" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeIn;">
            <div class="pricing-header">
                <h2 class="heading-2 pricing_name"><?php echo  $settings['pricing_name']; ?></h2>
                <h3 class="heading-3 for_package"><?php echo  $settings['for_package']; ?></h3>
                <h4 class="heading-4"><span class="pricing-big"><?php echo  $settings['price']; ?>  <span class="pricing-small">$/<?php echo  $settings['payment_duration']; ?></span> </span></h4>
            </div>
            <ul class="pricing-body list-inline">
                <?php 
                    foreach($plan_list as $plan){?>
                        <li class="list-inline price-plan"><?php echo $plan['pricing_plan']; ?></li>
                    <?php
                    }
                ?>
            </ul>
            <div class="pricing-footer"><a href="<?php echo $settings['button_link']['url']; ?>" class="pricing-btn"><?php echo $settings['button_label']?></a></div>
         </div>
    <?php
    }
}
