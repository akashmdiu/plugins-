<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostTLDPlan extends Widget_Base {

	public function get_name() {
		return 'tld-plan';
	}

	public function get_title() {
		return __( 'TLD Plan', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-exchange';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'table-content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        $repeater = new \Elementor\Repeater();
    
            $repeater->add_control(
                'domain', [
                    'label' => __( 'Domain', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '.com' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'whois_guard', [
                    'label' => __( 'WhoisGuard', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'yes',
                    'options' => [
                        'yes'  => __( 'Yes', 'axiohost-elementor-addons' ),
                        'no' => __( 'No', 'axiohost-elementor-addons' ),
                    ],
        
                ]
            );
            $repeater->add_control(
                'free_ssl', [
                    'label' => __( 'Free SSL', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'yes',
                    'options' => [
                        'yes'  => __( 'Yes', 'axiohost-elementor-addons' ),
                        'no' => __( 'No', 'axiohost-elementor-addons' ),
                    ],
                ]
            );
            $repeater->add_control(
                'price', [
                    'label' => __( 'Price/Year', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '$30.00 (Renewal Price $51.00)' , 'axiohost-elementor-addons' ),
                    'label-block' => true
                ]
            );
            
    
            $this->add_control(
                'tld_plan_list',
                [
                    'label' => __( 'TLD Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'domain' => __( '.com', 'axiohost-elementor-addons' ),
                            'price' => __( '$30.00 (Renewal Price $51.00)', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'domain' => __( '.net', 'axiohost-elementor-addons' ),
                            'price' => __( '$20.00 (Renewal Price $25.00)', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ domain }}}',
                ]
            );
            
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'tld_plan_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'tld_heading_style',
            [
				'label' => __( 'Heading Style', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'heading_bg',
			[
				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table thead' => 'background-color: {{VALUE}}',
                ],
                'default' => '#8066dc'
			]
        );
        $this->add_control(
			'heading_color',
			[
				'label' => __( 'Label Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table thead th' => 'color: {{VALUE}}',
                ],
                'default' => '#fff'
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typo',
				'label' => __( 'Label Typography', 'axiohost-elementor-addons' ), 
				'selector' => '{{WRAPPER}} .plan-list-table thead th',
			]
		);
        
        
        $this->add_control(
			'tld_data',
			[
				'label' => __( 'TLD Data', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
            ]
		);
        $this->add_control(
			'tld_data_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table tbody td' => 'color: {{VALUE}}',
                ],
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tld_data_typo',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}}   .plan-list-table tbody td',
			]
		);

        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $tld_list = $settings['tld_plan_list'];?>
        <table class="plan-list-table table">
            <thead>
                <tr>
                <th>Domain </th>
                <th>WhoisGuard </th>
                <th>Free SSL</th>
                <th>Price/Year</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ( $tld_list as $single_tld ) {?>
                        <tr>
                            <td> <?php echo $single_tld['domain']; ?></td>
                            <td><?php echo $single_tld['whois_guard']; ?></td>
                            <td><?php echo $single_tld['free_ssl']; ?></td>
                            <td><?php echo $single_tld['price']; ?></td>
                        </tr>
                        <?php   
                    }
                ?>
            </tbody>
        </table>
        
    <?php
    }
}
