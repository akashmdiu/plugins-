<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostPricingPlan extends Widget_Base {

	public function get_name() {
		return 'pricing-plan';
	}

	public function get_title() {
		return __( 'Pricing Plan', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'eicon-price-list';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'table-content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        $this->start_controls_tabs( 'pricing_plan_tab' );

        $this->start_controls_tab(
            'monthly',
            [
                'label' => __( 'Monthly', 'axiohost-elementor-addons' ),
            ]
        );
    
            $repeater = new \Elementor\Repeater();
    
            $repeater->add_control(
                'server_name', [
                    'label' => __( 'Server Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Server #324	' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'processor', [
                    'label' => __( 'Processor', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Quad Core -x3430' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'cache', [
                    'label' => __( 'Cache', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '2.4 Ghz/8MB' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'threads', [
                    'label' => __( 'Threads', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'ram', [
                    'label' => __( 'RAM', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4GB' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'storage', [
                    'label' => __( 'Storage', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '1 TB (SATA)' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'price', [
                    'label' => __( 'Price', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '$40/mo' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'configure_label', [
                    'label' => __( 'Configure Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Configure' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'configure_url', [
                    'label' => __( 'Configure URL', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                    'placeholder' => 'https://your-link.com',
                    'label-block' => 'true'
                ]
            );
    
            $this->add_control(
                'pricing_plan_list',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'server_name' => __( 'Server #324', 'axiohost-elementor-addons' ),
                            'processor' => __( 'Quad Core -x3430', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'server_name' => __( 'Server #325	', 'axiohost-elementor-addons' ),
                            'processor' => __( 'Xeon E3-1220', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ server_name }}}',
                ]
            );
    
        $this->end_controls_tab();
    
        $this->start_controls_tab(
            'yearly',
            [
                'label' => __( 'Yearly', 'axiohost-elementor-addons' ),
            ]
        );
            $repeater = new \Elementor\Repeater();
    
            $repeater->add_control(
                'server_name_y', [
                    'label' => __( 'Server Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Server #324	' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'processor_y', [
                    'label' => __( 'Processor', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Quad Core -x3430' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'cache_y', [
                    'label' => __( 'Cache', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '2.4 Ghz/8MB' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'threads_y', [
                    'label' => __( 'Threads', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'ram_y', [
                    'label' => __( 'RAM', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4GB' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'storage_y', [
                    'label' => __( 'Storage', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '1 TB (SATA)' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'price_y', [
                    'label' => __( 'Price', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '$40/mo' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'configure_label_y', [
                    'label' => __( 'Configure Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Configure' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'configure_url_y', [
                    'label' => __( 'Configure URL', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                    'placeholder' => 'https://your-link.com',
                    'label-block' => 'true'
                ]
            );
    
            $this->add_control(
                'pricing_plan_list_y',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'server_name_y' => __( 'Server #324', 'axiohost-elementor-addons' ),
                            'processor_y' => __( 'Quad Core -x3430', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'list_title_y' => __( 'Server #325	', 'axiohost-elementor-addons' ),
                            'processor_y' => __( 'Xeon E3-1220', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ server_name_y }}}',
                ]
            );
       
    
        $this->end_controls_tab();
    
    $this->end_controls_tabs();
            
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'pricing_plan_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'pricing_heading_style',
            [
				'label' => __( 'Heading Style', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'heading_bg',
			[
				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table thead' => 'background-color: {{VALUE}}',
                ],
                'default' => '#8066dc'
			]
        );
        $this->add_control(
			'heading_color',
			[
				'label' => __( 'Label Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table thead th' => 'color: {{VALUE}}',
                ],
                'default' => '#fff'
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typo',
				'label' => __( 'Label Typography', 'plugin-domain' ), 
				'selector' => '{{WRAPPER}} .pricing-plan-table thead th',
			]
		);
        $this->add_control(
			'server_name_style',
			[
				'label' => __( 'Server Name', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
                
            ]
		);
        $this->add_control(
			'server_name_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table tbody tr td:first-child' => 'color: {{VALUE}}',
                ],
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'server_name_typo',
				'label' => __( 'Typography', 'plugin-domain' ),
				 
				'selector' => '{{WRAPPER}}  .pricing-plan-table tbody tr td:first-child',
			]
		);
        $this->add_control(
			'service_data',
			[
				'label' => __( 'Service Data', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
            ]
		);
        $this->add_control(
			'service_data_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table tbody td' => 'color: {{VALUE}}',
                ],
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'service_data_typo',
				'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}}   .pricing-plan-table tbody td',
			]
		);
        $this->add_control(
			'configure_label_style',
			[
				'label' => __( 'Configure Label', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
            ]
		);
        $this->add_control(
			'configure_label_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table tbody td .pricing-btn' => 'color: {{VALUE}}',
                ],
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'configure_label_typo',
				'label' => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}}   .pricing-plan-table tbody td .pricing-btn',
			]
		);
        $this->add_control(
			'configure_label_border_color',
			[
				'label' => __( 'Border Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .pricing-plan-table tbody td .pricing-btn' => 'border-color: {{VALUE}}',
                ],
			]
        );



        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $plan_list = $settings['pricing_plan_list'];
    $plan_list_y = $settings['pricing_plan_list_y'];?>
        <ul class="pricing-plan-controls d-flex justify-content-center  nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link controls-btn" id="monthly-tab" data-toggle="tab" href="#monthly" role="tab" aria-selected="false">Monthly</a>
            </li>
            <li class="nav-item">
                <a class="nav-link controls-btn  active show" id="yearly-tab" data-toggle="tab" href="#yearly" role="tab" aria-selected="true">Yearly</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade" id="monthly" role="tabpanel">
            <div class="row">
                    <div class="col">
                        <table class="pricing-plan-table table">
                            <thead>
                                <tr>
                                <th>Server Name </th>
                                <th>Processor </th>
                                <th>Cache </th>
                                <th> Threads</th>
                                <th> RAM</th>
                                <th> Storage</th>
                                <th> Price</th>
                                <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach ( $plan_list as $single_plan ) {?>
                                        <tr>
                                            <td><?php echo $single_plan['server_name']; ?></td>
                                            <td><?php echo $single_plan['processor']; ?></td>
                                            <td><?php echo $single_plan['cache']; ?> </td>
                                            <td><?php echo $single_plan['threads']; ?></td>
                                            <td><?php echo $single_plan['ram']; ?></td>
                                            <td><?php echo $single_plan['storage']; ?></td>
                                            <td><?php echo $single_plan['price']; ?></td>
                                            <td><a href="<?php echo $single_plan['configure_url']['url']; ?>" class="pricing-btn"><?php echo $single_plan['configure_label']; ?></a></td>
                                        </tr>  
                                        <?php   
                                    }
                                ?>
                                    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade active show" id="yearly" role="tabpanel">
                <div class="row">
                    <div class="col">
                        <table class="pricing-plan-table table">
                            <thead>
                                <tr>
                                <th>Server Name </th>
                                <th>Processor </th>
                                <th>Cache </th>
                                <th> Threads</th>
                                <th> RAM</th>
                                <th> Storage</th>
                                <th> Price</th>
                                <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach ( $plan_list_y as $single_plan ) {?>
                                        <tr>
                                            <td><?php echo $single_plan['server_name_y']; ?></td>
                                            <td><?php echo $single_plan['processor_y']; ?></td>
                                            <td><?php echo $single_plan['cache_y']; ?> </td>
                                            <td><?php echo $single_plan['threads_y']; ?></td>
                                            <td><?php echo $single_plan['ram_y']; ?></td>
                                            <td><?php echo $single_plan['storage_y']; ?></td>
                                            <td><?php echo $single_plan['price_y']; ?></td>
                                            <td><a href="<?php echo $single_plan['configure_url_y']['url']; ?>" class="pricing-btn"><?php echo $single_plan['configure_label_y']; ?></a></td>
                                        </tr>  
                                        <?php   
                                    }
                                ?>
                                    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }
}
