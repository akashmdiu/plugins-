<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostPriceTable1 extends Widget_Base {

	public function get_name() {
		return 'price-table';
	}

	public function get_title() {
		return __( 'Price Table1', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'title_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'pricing_badge',
                [
                    'label' => __( 'Pricing Badge', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'On', 'your-plugin' ),
                    'label_off' => __( 'Off', 'your-plugin' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'base_label',
                [
                    'label' => __( 'Badge Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Popular', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'pricing_name',
                [
                    'label' => __( 'Pricing Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Basic', 'axiohost-elementor-addons' ),
                ]
            );  
            $this->add_control(
                'package_name',
                [
                    'label' => __( 'Package Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Starter Package', 'axiohost-elementor-addons' ),
                ]
            ); 
            $this->add_control(
                'price',
                [
                    'label' => __( 'Price', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Free', 'axiohost-elementor-addons' ),
                ]
            );   
            $repeater = new \Elementor\Repeater();
            $repeater->add_control(
                'pricing_plan',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => '13 GB storage',
                ]
            );
            $this->add_control(
                'plan_list',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'pricing_plan' => __( 'Pricing Plan #1', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'pricing_plan' => __( 'Pricing Plan #2', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{pricing_plan}}}',
                ]
            );

            $this->add_control(
                'pricing_button',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_label',
                [
                    'label' => __( 'Button Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Buy Now', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'service_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'table_background',
                [
                    'label' => __( 'Table Background', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-plan-box4' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'base_label_style',
                [
                    'label' => __( 'Base label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'base_label_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-badge' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'base_label_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-badge',
                ]
            );
            $this->add_control(
                'base_label_bgcolor',
                [
                    'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-badge' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'pricing_name_style',
                [
                    'label' => __( 'Pricing Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'pricing_name_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-name' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'pricing_name_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-name',
                ]
            );
            $this->add_control(
                'pricing_name_bgcolor',
                [
                    'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-name' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'pricing_name_border_color',
                [
                    'label' => __( 'Border Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-name' => 'border-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'package_name_style',
                [
                    'label' => __( 'Package Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'package_name_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .package-name' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'package_name_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .package-name',
                ]
            );

            $this->add_control(
                'price_style',
                [
                    'label' => __( 'Price', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'price_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .price' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'price_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .price',
                ]
            );

            $this->add_control(
                'plan_style',
                [
                    'label' => __( 'Pricing Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'plan_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .price-plan' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'plan_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .price-plan',
                ]
            );

            $this->add_control(
                'button_style',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'button_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .pricing-btn',
                ]
            );
            $this->add_control(
                'button_bgcolor',
                [
                    'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'button_border_color',
                [
                    'label' => __( 'Border Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn' => 'border-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'hover_button_bgcolor',
                [
                    'label' => __( 'Hover Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn:hover' => 'background-color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                '_hover_button_border_color',
                [
                    'label' => __( 'Hover Border Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-btn:hover' => 'border-color: {{VALUE}}',
                    ],
                ]
            );


        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $plan_list = $settings['plan_list'];?>
        <div class="pricing-plan-box4">
            <div class="pricing-header">
               <span class="pricing-name pricing-name2"><?php echo $settings['pricing_name']; ?></span>
			   <h3 class="heading-3 package-name"><?php echo $settings['package_name']; ?></h3>
               <h2 class="heading-2 price"><?php echo $settings['price']; ?></h2>
               <?php 
                   if($settings['pricing_badge'] == 'yes'){
                      echo '<div class="pricing-badge">'.$settings['base_label'].'</div>';
                       
                   }
               ?>
            </div>
            <ul class="pricing-body list-inline">
                <?php 
                    foreach($plan_list as $plan){
                        echo '<li class="list-inline price-plan">'.$plan['pricing_plan'].'</li>';
                    }
                ?>
            </ul>
            <div class="pricing-footer"><a href="<?php echo $settings['button_link']['url']; ?>" class="pricing-btn"><?php echo $settings['button_label']; ?></a></div>
         </div>
    <?php
    }
}
