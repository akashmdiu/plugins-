<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostVPSHostingPlan extends Widget_Base {

	public function get_name() {
		return 'vps-hosting-plan';
	}

	public function get_title() {
		return __( 'VPS Hosting Plan', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-database';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'table-content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        $this->start_controls_tabs( 'pricing_plan_tab' );

        $this->start_controls_tab(
            'monthly',
            [
                'label' => __( 'Monthly', 'axiohost-elementor-addons' ),
            ]
        );
    
            $repeater = new \Elementor\Repeater();
    
            $repeater->add_control(
                'features', [
                    'label' => __( 'Features', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'vCPU' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'linux_vps', [
                    'label' => __( 'Linux VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'storage_vps', [
                    'label' => __( 'Storage VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'windows_vps', [
                    'label' => __( 'Windows VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '3' , 'axiohost-elementor-addons' ),
                ]
            );
    
            $this->add_control(
                'vps_plan_list',
                [
                    'label' => __( 'VPS Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'features' => __( 'vCPU', 'axiohost-elementor-addons' ),
                            'linux_vps' => __( '4', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'features' => __( 'Memory	', 'axiohost-elementor-addons' ),
                            'linux_vps' => __( '4', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ features }}}',
                ]
            );
            $this->add_control(
                'pricing_button',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_label',
                [
                    'label' => __( 'Button Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Buy Now', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'button_link1',
                [
                    'label' => __( 'Button Link1', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'button_link2',
                [
                    'label' => __( 'Button Link2', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'button_link3',
                [
                    'label' => __( 'Button Link3', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
    
        $this->end_controls_tab();
    
        $this->start_controls_tab(
            'yearly',
            [
                'label' => __( 'Yearly', 'axiohost-elementor-addons' ),
            ]
        );
            $repeater = new \Elementor\Repeater();
    
            $repeater->add_control(
                'features_y', [
                    'label' => __( 'Features', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'SSD Space	' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'linux_vps_y', [
                    'label' => __( 'Linux VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'storage_vps_y', [
                    'label' => __( 'Storage VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '4' , 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'windows_vps_y', [
                    'label' => __( 'Windows VPS', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '3' , 'axiohost-elementor-addons' ),
                ]
            );
            
    
            $this->add_control(
                'vps_plan_list_y',
                [
                    'label' => __( 'VPS Plan', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'features_y' => __( 'Monthly Traffic', 'axiohost-elementor-addons' ),
                            'linux_vps_y' => __( '4', 'axiohost-elementor-addons' ),
                        ],
                        [
                            'features_y' => __( 'Monthly Traffic', 'axiohost-elementor-addons' ),
                            'linux_vps_y' => __( '4', 'axiohost-elementor-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ features_y }}}',
                ]
            );
            $this->add_control(
                'pricing_button_y',
                [
                    'label' => __( 'Button', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'button_label_y',
                [
                    'label' => __( 'Button Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Buy Now', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'button_link_y1',
                [
                    'label' => __( 'Button Link1', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'button_link_y2',
                [
                    'label' => __( 'Button Link2', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'button_link_y3',
                [
                    'label' => __( 'Button Link3', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::URL,
                ]
            );
    
        $this->end_controls_tab();
    
    $this->end_controls_tabs();
            
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'vps_plan_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'vps_heading_style',
            [
				'label' => __( 'Heading Style', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'heading_bg',
			[
				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table thead' => 'background-color: {{VALUE}}',
                ],
                'default' => '#8066dc'
			]
        );
        $this->add_control(
			'heading_color',
			[
				'label' => __( 'Label Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table thead th' => 'color: {{VALUE}}',
                ],
                'default' => '#fff'
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typo',
				'label' => __( 'Label Typography', 'axiohost-elementor-addons' ), 
				'selector' => '{{WRAPPER}}.plan-list-table thead th',
			]
		);
        
        $this->add_control(
			'vps_data',
			[
				'label' => __( 'VPS Hosting Data', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
            ]
		);
        $this->add_control(
			'vps_data_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table tbody td' => 'color: {{VALUE}}',
                ],
			]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vps_data_typo',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}}   .plan-list-table tbody td',
			]
		);
        $this->add_control(
			'buy_now1_style',
			[
				'label' => __( 'Buy Now', 'axiohost-elementor-addons' ),
                'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
            ]
		);
        $this->add_control(
			'buy_now1_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-list-table tbody td .plan-btn' => 'color: {{VALUE}}',
                ],
                'default' => 'white'
			]
        );
        $this->add_control(
			'buy_now1_bg_color',
			[
				'label' => __( 'Button1 BG Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-color1' => 'background-color: {{VALUE}}',
                ],
                'default' => '#3AD984'
			]
        );
        $this->add_control(
			'buy_now2_bg_color',
			[
				'label' => __( 'Button2 BG Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-color2' => 'background-color: {{VALUE}}',
                ],
                'default' => '#FFA939'
			]
        );
        $this->add_control(
			'buy_now3_bg_color',
			[
				'label' => __( 'Button3 BG Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .plan-color3' => 'background-color: {{VALUE}}',
                ],
                'default' => '#F23D78'
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'buy_now1_typo',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}}   .plan-list-table tbody td .plan-btn',
			]
		);
        

        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $plan_list = $settings['vps_plan_list'];
    $plan_list_y = $settings['vps_plan_list_y'];?>
        <ul class="pricing-plan-controls d-flex justify-content-center  nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link controls-btn active show" id="monthly-tab" data-toggle="tab" href="#monthly" role="tab" aria-selected="true">Monthly</a>
            </li>
            <li class="nav-item">
                <a class="nav-link controls-btn" id="yearly-tab" data-toggle="tab" href="#yearly" role="tab" aria-selected="false">Yearly</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade active show" id="monthly" role="tabpanel">
                <div class="row">
                <div class="col">
                <div class=" pt-0 table-responsive-md">
                <table class="plan-list-table table">
                    <thead>
                        <tr>
                            <th>Features </th>
                            <th>Linux VPS </th>
                            <th>Storage VPS</th>
                            <th>Windows VPS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach ( $plan_list as $single_plan ) {?>
                                <tr>
                                    <td><?php echo $single_plan['features']; ?></td>
                                    <td><?php echo $single_plan['linux_vps']; ?></td>
                                    <td><?php echo $single_plan['storage_vps']; ?> </td>
                                    <td><?php echo $single_plan['windows_vps']; ?></td>
                                </tr>  
                                <?php   
                            }
                        ?>
                        <tr>
                            <td> </td>
                                <td><a href="<?php echo $settings['button_link1']['url']; ?>" class="plan-btn plan-color1"><?php echo $settings['button_label']; ?></a></td>
                                <td><a href="<?php echo $settings['button_link2']['url']; ?>" class="plan-btn plan-color2"><?php echo $settings['button_label']; ?></a></td>
                                <td><a href="<?php echo $settings['button_link3']['url']; ?>" class="plan-btn plan-color3"><?php echo $settings['button_label']; ?></a></td>
                            </tr>
                    </tbody>
                </table>		
                </div>
                </div>
                </div>
            </div>
            <div class="tab-pane fade" id="yearly" role="tabpanel">
                <div class="row">
                <div class="col">
                <div class="section-spacing pt-0 table-responsive-md">
                <table class="plan-list-table table">
                    <thead>
                        <tr>
                        <th>Features </th>
                        <th>Linux VPS </th>
                        <th>Storage VPS</th>
                        <th>Windows VPS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach ( $plan_list_y as $single_plan ) {?>
                                    <tr>
                                        <td><?php echo $single_plan['features_y']; ?></td>
                                        <td><?php echo $single_plan['linux_vps_y']; ?></td>
                                        <td><?php echo $single_plan['storage_vps_y']; ?> </td>
                                        <td><?php echo $single_plan['windows_vps_y']; ?></td>
                                    </tr>  
                                <?php   
                            }
                        ?>
                        <tr>
                            <td> </td>
                            <td><a href="<?php echo $settings['button_link_y1']['url']; ?>" class="plan-btn plan-color1"><?php echo $single_plan['button_label_y']; ?></a></td>
                                <td><a href="<?php echo $settings['button_link_y2']['url']; ?>" class="plan-btn plan-color2"><?php echo $settings['button_label_y']; ?></a></td>
                                <td><a href="<?php echo $settings['button_link_y3']['url']; ?>" class="plan-btn plan-color3"><?php echo $settings['button_label_y']; ?></a></td>
                            </tr>
                    </tbody>
                </table>		
                </div>
                </div>
                </div>
            </div>
        </div>
        
    <?php
    }
}
