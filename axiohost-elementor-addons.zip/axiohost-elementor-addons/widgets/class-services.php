<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostService extends Widget_Base {

	public function get_name() {
		return 'service-box';
	}

	public function get_title() {
		return __( 'Service Box', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-cogs';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'title_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
            $repeater = new \Elementor\Repeater();
            $repeater->add_control(
                'service_icon',
                [
                    'label' => __( 'Service Icon', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::ICON,
                    'default' => 'fa-database'
                ]
            );
            
            $repeater->add_control(
                'service_name',
                [
                    'label' => __( 'Service Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Cloud Hosting', 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'service_tag',
                [
                    'label' => __( 'Service Tag', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Safe and Secured', 'axiohost-elementor-addons' ),
                ]
            );
            $repeater->add_control(
                'service_desc',
                [
                    'label' => __( 'Service Short Description', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => __( 'Best cloud hosting omnis iste natus error sit volupta tem accusantium doloremque totam', 'axiohost-elementor-addons' ),
                ]
            );
            $this->add_control(
                'service_list',
                [
                    'label' => __( 'Service List', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'service_name' => __( 'Service #1', 'axiohost-elementor-addons' ),
                            'service_tag' => __('Safe and Secured', 'axiohost-elementor-addons'),
                        ],
                        [
                            'service_name' => __( 'Service #2', 'axiohost-elementor-addons' ),
                            'service_tag' => __('Safe and Secured', 'axiohost-elementor-addons'),
                        ],
                    ],
                    'title_field' => '{{{service_name}}}',
                ]
            );
        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
			'service_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'service_box_heading',
                [
                    'label' => __( 'Service Box', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            
            $this->add_control(
                'service_bg_color',
                [
                    'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-box' => 'background-color: {{VALUE}}',
                    ],
                    'default' => '#fff'
                ]
            );
            $this->add_control(
                'service_bg_hover_color',
                [
                    'label' => __( 'Hover BG Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-box:hover' => 'background-color: {{VALUE}}',
                    ],
                    'default' => '#8066dc'
                ]
            );
            $this->add_control(
                'service_box_bar_color',
                [
                    'label' => __( 'Service Box Bar Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-box:before' => 'background-color: {{VALUE}}',
                    ],
                    'default' => '#fff'
                ]
            );
            $this->add_control(
                'service_hover_content_color',
                [
                    'label' => __( 'Hover Content Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-box:hover .service-logo .fa,.service-box:hover .service-heading .heading-4,.service-box:hover .service-heading > p,.service-box:hover .service-content > p' => 'color: {{VALUE}}',
                    ],
                    'default' => '#fff'
                ]
            );
            $this->add_control(
                'service_icon_heading',
                [
                    'label' => __( 'Service Icon', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'service_icon_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-logo .fa' => 'color: {{VALUE}}',
                    ],
                ]
            );
            

            $this->add_control(
                'icon_size',
                [
                    'label' => __( 'Icon Size', 'plugin-domain' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 100,
                            'step' => 1,
                        ]
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 35,
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .service-logo .fa' => 'font-size: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'service_name_heading',
                [
                    'label' => __( 'Service Name', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'service_name_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-heading .heading-4' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'service_name_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .service-heading .heading-4',
                ]
            );

            $this->add_control(
                'service_tag_heading',
                [
                    'label' => __( 'Service Tag', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'service_tag_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-heading > p' => 'color: {{VALUE}}',
                    ],
                ]
            );
           
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'service_tag_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .service-heading > p',
                ]
            );

            $this->add_control(
                'service_desc_heading',
                [
                    'label' => __( 'Service Desc', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'service_desc_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .service-content > p' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'service_desc_typo',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .service-content > p',
                ]
            );

        $this->end_controls_section();

	}
	
protected function render() {
    $settings = $this->get_settings_for_display();
    $service_list = $settings['service_list'];
        echo '<div class="row">';
            foreach($service_list as $service){?>
                <div class="col-md-6 col-lg-4">
                    <div class="service-box wow fadeIn" data-wow-duration="1s">
                        <div class="service-title">
                            <div class="service-logo"><i class="fa <?php echo $service['service_icon']; ?>"></i></div>
                            <div class="service-heading">
                                <h4 class="heading-4"><?php echo $service['service_name']; ?></h4>
                                <p><?php echo $service['service_tag']; ?></p>
                            </div>
                        </div>
                        <div class="service-content">
                            <p><?php echo $service['service_desc']; ?></p>
                        </div>
                    </div>
                </div>
            <?php
            }
        echo '</div>';
    }
}
