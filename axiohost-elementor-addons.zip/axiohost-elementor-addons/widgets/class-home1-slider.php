<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostHome1Slider extends Widget_Base {

	public function get_name() {
		return 'home1-slider';
	}

	public function get_title() {
		return __( 'Home1 Slider', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-sliders';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'home_slider_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'content_heading',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'slide_image',
			[
				'label' => __( 'Slide Image', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __('Upload an slide image'),
				'label_block' => true,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$repeater->add_control(
			'slide_title',
			[
				'label' => __( 'Slide Title', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Baisc Hosting Plan', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input slide title here', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'slide_subtitle',
			[
				'label' => __( 'Slide Subtitle', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input slide subtitle here', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		
		
		
		$repeater->add_control(
			'slide_btn_label',
			[
				'label' => __( 'Button Label', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Get Supports', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'slide_buton_link',
			[
				'label' => __( 'Link', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'axiohost-elementor-addons' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
        
		$this->add_control(
			'slide_list',
			[
				'label' => __( 'Slide Item List', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'slide_title' => __( 'Slide Item #1', 'axiohost-elementor-addons' ),
                        'slide_btn_label' => __('Get Support', 'axiohost-elementor-addons'),
					],
					[
						'slide_title' => __( 'Slide Item #2', 'axiohost-elementor-addons' ),
                        'slide_btn_label' => __('Explore Topics', 'axiohost-elementor-addons'),
					],
				],
				'title_field' => '{{{ slide_title}}}',
			]
		);
		

        $this->end_controls_section();
        
        //Style Tab
        $this->start_controls_section(
			'home1_slide_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
        
        $this->add_control(
			'slide_title_heading',
			[
				'label' => __( 'Title', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'slide_title_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} h2.style-two' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} h2.style-two',
				'default' => '',
				
			]
		);
		
		$this->add_responsive_control(
			'width',
			[
				'label' => __( 'Spacing', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 60,
				],
				'selectors' => [
					'{{WRAPPER}} h2.style-two' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'slide_subtitle_heading',
			[
				'label' => __( 'Subtitle', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'slide_subtitle_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .content-box.center-align .text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .content-box.center-align .text',
				'default' => '',
				
			]
		);
        $this->add_responsive_control(
			'text-spacing',
			[
				'label' => __( 'Spacing', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 60,
				],
				'selectors' => [
					'{{WRAPPER}} .content-box.center-align .text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
        $this->add_control(
			'slide_btn_heading',
			[
				'label' => __( 'Button', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
		$this->start_controls_tabs( 'tabs_button_style' );

    		$this->start_controls_tab(
    			'tab_button_normal',
    			[
    				'label' => __( 'Normal', 'axiohost-elementor-addons' ),
    			]
    		);
    		    $this->add_control(
        			'button_text_color',
        			[
        				'label' => __( 'Text Color', 'axiohost-elementor-addons' ),
        				'type' => \Elementor\Controls_Manager::COLOR,
        				'selectors' => [
        					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn' => 'color: {{VALUE}}',
        				],
        			]
        		);
        		$this->add_control(
        			'button_bg_color',
        			[
        				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
        				'type' => \Elementor\Controls_Manager::COLOR,
        				'selectors' => [
        					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn' => 'background-color: {{VALUE}}',
        				],
        			]
        		);
        		
                
    		
    		$this->end_controls_tab();
    		
    		$this->start_controls_tab(
    			'tab_button_hover',
    			[
    				'label' => __( 'Hover', 'axiohost-elementor-addons' ),
    			]
    		);
    		
    		    $this->add_control(
        			'button_text_hover_color',
        			[
        				'label' => __( 'Text Color', 'axiohost-elementor-addons' ),
        				'type' => \Elementor\Controls_Manager::COLOR,
        				'selectors' => [
        					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn:hover' => 'color: {{VALUE}}',
        				],
        			]
        		);
        		$this->add_control(
        			'button_bg_hover_color',
        			[
        				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
        				'type' => \Elementor\Controls_Manager::COLOR,
        				'selectors' => [
        					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn:hover' => 'background-color: {{VALUE}}',
        				],
        			]
        		);
    		$this->end_controls_tab();
		$this->end_controls_tabs( );
		

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .banner-carousel2 .link-box .theme-btn',
			]
		);
		$this->add_responsive_control(
			'text_padding',
			[
				'label' => __( 'Padding', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .banner-carousel2 .link-box .theme-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
        $this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['slide_list'] ) {
		    
			echo '<div class="banner-carousel2 owl-carousel owl-theme">';
			foreach (  $settings['slide_list'] as $item ) {?>
				    <div class="slide-item" style="background-image : url('<?php echo $item['slide_image']['url']; ?>'); ">
                        <div class="auto-container clearfix">
                            <!-- Content Box -->
                            <div class="content-box center-align">
                                <div class="inner alternate">
                                    <h2 class="style-two"><?php echo $item['slide_title']; ?></h2>
                                    <div class="text"><?php echo $item['slide_subtitle']; ?></div>
                                    <div class="link-box">
                                        <a href="<?php echo $item['slide_buton_link']['url']; ?>" class="theme-btn btn-style-seven"><?php echo $item['slide_btn_label']; ?><span class="arrow flaticon-next-8"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				    
                <?php   
			}
			echo '</div>';?>
			
			<script src="<?php echo site_url(); ?>/wp-content/plugins/axiohost-elementor-addons/assets/js/owl-carousel.min.js"></script>
			<script>	
        		/* ==========================================
                  2.    banner-slider   
            ========================================== */
            if ( jQuery('.mainSlider').length ) {
                jQuery('.mainSlider').nivoSlider({
                    manualAdvance: false,  
                    directionNav: true,
                    animSpeed: 500,
                    slices: 18,
                    pauseTime: 10000,
                    pauseOnHover: true,
                    controlNav: false,
                    prevText: '<i class="fa fa-angle-left nivo-prev-icon"></i>',
                    nextText: '<i class="fa fa-angle-right nivo-next-icon"></i>'
                  });
                }
        
        		if (jQuery('.banner-carousel2').length) {
            		jQuery('.banner-carousel2').owlCarousel({
            			animateOut: 'slideOutUp',
                		animateIn: 'fadeDown',
            			loop:true,
            			margin:0,
            			nav:true,
            			singleItem:true,
            			smartSpeed: 500,
            			autoHeight: false,
            			autoplay: true,
            			autoplayTimeout:10000,
            			navText: [ '<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>' ],
            			responsive:{
            				0:{
            					items:1
            				},
            				600:{
            					items:1
            				},
            				1024:{
            					items:1
            				},
            			}
            		});    		
        	}
        	</script>
		<?php
		}
	}
}
