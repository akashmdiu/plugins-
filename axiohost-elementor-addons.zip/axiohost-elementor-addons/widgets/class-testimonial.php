<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostTestimonial extends Widget_Base {

	public function get_name() {
		return 'testimonial';
	}

	public function get_title() {
		return __( 'Testimonial', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'home_slider_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
        
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'review1',
			[
				'label' => __( 'Review1', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'reviewer_image',
			[
				'label' => __( 'Chose Image', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __('Upload Reviewer Image'),
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'reviewer_name',
			[
				'label' => __( 'Reviewer Name', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Vit Lee', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input reviewer name', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'reviewer_website',
			[
				'label' => __( 'Url', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://url-link.com', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'reviewer_designation',
			[
				'label' => __( 'Designation', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'UI/UX Designer','axiohost-elementor-addons' ),
				'placeholder' => __( 'Input reviewer designation', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'review',
			[
				'label' => __( 'Review', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit scelerisque in dictum non consectetur a erat nam at lectus urna duis convallis  .', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input testimonial', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'review2',
			[
				'label' => __( 'Review2', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'reviewer_image2',
			[
				'label' => __( 'Chose Image', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __('Upload Reviewer Image'),
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'reviewer_name2',
			[
				'label' => __( 'Reviewer Name', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Vit Lee', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input reviewer name', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'reviewer_website2',
			[
				'label' => __( 'Url', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://url-link.com', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'reviewer_designation2',
			[
				'label' => __( 'Designation', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'UI/UX Designer','axiohost-elementor-addons' ),
				'placeholder' => __( 'Input reviewer designation', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'review_text2',
			[
				'label' => __( 'Review', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit scelerisque in dictum non consectetur a erat nam at lectus urna duis convallis  .', 'axiohost-elementor-addons' ),
				'placeholder' => __( 'Input testimonial', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'testimonial_list',
			[
				'label' => __( 'Testimonial', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'reviewer_name' => __( 'John Doe', 'axiohost-elementor-addons' ),
						'reviewer_designation' => __('Software Engineer', 'axiohost-elementor-addons'),
						'reviewer_name2' => __( 'Bit Lee', 'axiohost-elementor-addons' ),
                        'reviewer_designation2' => __('UX/UI Designer', 'axiohost-elementor-addons'),
					],
					[
						'reviewer_name' => __( 'Thomas Ran', 'axiohost-elementor-addons' ),
						'reviewer_designation' => __('Graphics Designer', 'axiohost-elementor-addons'),
						'reviewer_name2' => __( 'Joe Root', 'axiohost-elementor-addons' ),
						'reviewer_designation2' => __('Businessman', 'axiohost-elementor-addons'),
						
					],
				],
			]
		);
		

        $this->end_controls_section();
        
        //Style Tab
        $this->start_controls_section(
			'home1_slide_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
        
        $this->add_control(
			'name_heading',
			[
				'label' => __( 'Name', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'name_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .reviewer_name a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .reviewer_name a',
				'default' => '',
				
			]
		);
		
		$this->add_responsive_control(
			'name_spacing',
			[
				'label' => __( 'Spacing', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .reviewer_name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'designation',
			[
				'label' => __( 'Designation', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'designation_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .reviewer_designation' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .reviewer_designation',
				'default' => '',
				
			]
		);
        $this->add_responsive_control(
			'text-spacing',
			[
				'label' => __( 'Spacing', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .reviewer_designation' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'review_text',
			[
				'label' => __( 'Review', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'review_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .review' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'review_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .reviewer_designation',
				'default' => '',
				
			]
		);
        $this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['testimonial_list'] ) {
		    
			echo '<div class="testimonial-slider">';
			foreach (  $settings['testimonial_list'] as $item ) {?>
					<div class="testimonial-item">
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="testimonial-box wow fadeIn" data-wow-duration="1s">
									<div class="testimonial-img"><img src="<?php echo $item['reviewer_image']['url']; ?>" alt="testimonial img" /></div>
									<div class="testimonial-content">
										<h4 class="heading-4 reviewer_name"><a href="<?php echo $item['reviewer_website']['url']; ?>"><?php echo $item['reviewer_name']; ?></a></h4>
										<h6 class="heading-6 reviewer_designation"><?php echo $item['reviewer_designation']; ?></h6>
										<p class="review"><?php echo $item['review']; ?></p>
									</div>
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="testimonial-box wow fadeIn" data-wow-duration="1s">
									<div class="testimonial-img"><img src="<?php echo $item['reviewer_image2']['url']; ?>" alt="testimonial img" /></div>
									<div class="testimonial-content">
										<h4 class="heading-4 reviewer_name"><a href="<?php echo $item['reviewer_website2']['url']; ?>"><?php echo $item['reviewer_name2']; ?></a></h4>
										<h6 class="heading-6 reviewer_designation"><?php echo $item['reviewer_designation2']; ?></h6>
										<p class="review"><?php echo $item['review_text2']; ?></p>
									</div>
								</div>
							</div>
						</div>
					</div>	

                <?php   
			}
			echo '</div>';?>
			
			<script>	
        		/* ==========================================
                  2.testimonial-slider   
            ========================================== */
				jQuery('.testimonial-slider').slick({
					dots: true,
					autoplay: true,
					autoplaySpeed:5000,
					arrows:false,
					infinite: true,
					speed: 500,
					fade: false,
				});
        	</script>
		<?php
		}
	}
}
