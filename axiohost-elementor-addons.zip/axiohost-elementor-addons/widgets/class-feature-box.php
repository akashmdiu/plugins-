<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostFeatureBox extends Widget_Base {

	public function get_name() {
		return 'feature-box';
	}

	public function get_title() {
		return __( 'Feature Box', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'eicon-pojome';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'feature-box-content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'feature-box-alignment',
			[
				'label' => __( 'Alignment', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'axiohost-elementor-addons' ),
						'icon' => 'fa fa-align-left',
					],
					
					'right' => [
						'title' => __( 'Right', 'axiohost-elementor-addons' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
			]
		);
        
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'feature_icon',
			[
				'label' => __( 'Chose Icon Image', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __('Upload Icon Image'),
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'feature-name',
			[
				'label' => __( 'Feature Name', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '99.9% Up time', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'feature-desc',
			[
				'label' => __( 'Feature Description', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Do eiusmod ncididunt labore more seens', 'axiohost-elementor-addons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'feature-box-list',
			[
				'label' => __( 'Feature List', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'feature_name' => __( '
						99.9% Up time', 'axiohost-elementor-addons' ),
                        'feature_desc' => __('Do eiusmod ncididunt labore more seens', 'axiohost-elementor-addons'),
					],
					[
						'feature_name' => __( 'Unlimited storage', 'axiohost-elementor-addons' ),
                        'feature_desc' => __('Do eiusmod ncididunt labore more seens', 'axiohost-elementor-addons'),
					],
				],
				'title_field' => '{{{feature_name}}}',
			]
		);
		

        $this->end_controls_section();
        
        //Style Tab
        $this->start_controls_section(
			'feature-box-style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
		
		$this->add_control(
			'feature_icon_heading',
			[
				'label' => __( 'Feature Icon', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'feature_bg_color',
			[
				'label' => __( 'Background Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#6B53C1',
				'selectors' => [
					'{{WRAPPER}} ..feature-box .feature-logo' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_border_color',
			[
				'label' => __( 'Border Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#8066dc',
				'selectors' => [
					'{{WRAPPER}} .feature-box .feature-logo' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_hover_border_color',
			[
				'label' => __( 'Hover Border Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#e6e7efa6',
				'selectors' => [
					'{{WRAPPER}} .feature-box:hover .feature-logo' => 'border-color: {{VALUE}}',
				],
			]
		);
		
        $this->add_control(
			'feature_name_heading',
			[
				'label' => __( 'Feature Name', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'feature_name_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .feature-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_name_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .feature-name',
				
			]
		);
		
		$this->add_responsive_control(
			'feature_name_spacing',
			[
				'label' => __( 'Spacing', 'axiohost-elementor-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .feature-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'feature_desc_style',
			[
				'label' => __( 'Feature Description', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'feature_desc_color',
			[
				'label' => __( 'Color', 'axiohost-elementor-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .feature-desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_desc_typography',
				'label' => __( 'Typography', 'axiohost-elementor-addons' ),
				'selector' => '{{WRAPPER}} .feature-desc',
				'default' => '',
			]
		);
        
        $this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['feature-box-list'] ) {   ?> 
			<div class="feature-box-<?php if($settings['feature-box-alignment'] == 'left'){echo 'left'; }else{echo 'right'; }?>">
				<?php
				foreach (  $settings['feature-box-list'] as $item ) {?>
					
                        <div class="feature-box">
                            <div class="feature-logo wow bounceIn" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: bounceIn;">
                            <div class="feature_icon1" style="background-image: url('<?php echo $item['feature_icon']['url']; ?>')"></div>
                            </div>
                            <div class="feature-content">
                            <h4 class="heading-4 feature-name"><?php echo $item['feature-name']; ?></h4>
                            <p class="feature-desc"><?php echo $item['feature-desc']; ?></p>
                            </div>
                        </div>
                    
				<?php   
				}
			echo '</div>';?>
		
		<?php
		}
	}
}
