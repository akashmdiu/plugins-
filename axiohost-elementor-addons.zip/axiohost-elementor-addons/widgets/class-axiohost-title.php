<?php
namespace AxiohostElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class AxiohostTitle extends Widget_Base {

	public function get_name() {
		return 'axiohost-title';
	}

	public function get_title() {
		return __( 'Axiohost Title', 'axiohost-elementor-addons' );
	}

	public function get_icon() {
		return 'fa fa-header';
	}
	public function get_categories() {
		return [ 'axiohost-addons' ];
	}


    protected function _register_controls() {
	    
        //Content Tab
		$this->start_controls_section(
			'title_content',
			[
				'label' => __( 'Content', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'section_title',
                [
                    'label' => __( 'Title', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Why Choose Us', 'axiohost-elementor-addons' ),
                    'placeholder' => __( 'Type your section title here', 'axiohost-elementor-addons' ),
                    'label_block' => true
                ]
            );
            
            $this->add_control(
                'background_label',
                [
                    'label' => __( 'Background label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'W', 'axiohost-elementor-addons' ),
                ]
            );
        $this->end_controls_section();
        //Style Tab
        $this->start_controls_section(
			'axiohost_title_style',
			[
				'label' => __( 'Style', 'axiohost-elementor-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'title_style',
                [
                    'label' => __( 'Title', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-title .headeing-2' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'title_typography',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .section-title .headeing-2',
                ]
            );
            $this->add_control(
                'highlight_style',
                [
                    'label' => __( 'Highlight Word', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'highlight_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-title .headeing-2 span' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'highlight_typography',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .section-title .headeing-2 span',
                ]
            );
            $this->add_control(
                'bg_label_style',
                [
                    'label' => __( 'Background Label', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'bg_label_color',
                [
                    'label' => __( 'Color', 'axiohost-elementor-addons' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-label' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'bg_label_typography',
                    'label' => __( 'Typography', 'axiohost-elementor-addons' ),
                    'selector' => '{{WRAPPER}} .section-label',
                ]
            );
        $this->end_controls_section();
	}
	
	protected function render() {
        $settings = $this->get_settings_for_display();?>
            <div class="section-title">
                <h2 class="headeing-2"><?php echo $settings['section_title']; ?><span class="section-label"><?php echo $settings['background_label']; ?></span></h2>
             </div>
		<?php
	}
}
