<?php
namespace AxiohostElementorAddons;

/**
 * Class AxiohostElementorAddonsMain
 *
 * Main Plugin class
 * @since 1.2.0
 */
class AxiohostElementorAddonsMain {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * widget_style
	 *
	 * Load main style files.
	 *
	 * @since 1.0.0
	 * @access public
	 */

	public function widget_styles() {
	    //css style
		wp_register_style( 'owl-carousel', plugins_url( '/assets/css/owl.carousel.min.css', __FILE__ ) );
		wp_enqueue_style( 'owl-carousel' );
	    
		
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function include_axiohost_addon_files() {
		require_once( __DIR__ . '/widgets/class-home1-slider.php' );
		require_once( __DIR__ . '/widgets/class-axiohost-title.php' );
		require_once( __DIR__ . '/widgets/class-services.php' );
		require_once( __DIR__ . '/widgets/class-price-table1.php' );
		require_once( __DIR__ . '/widgets/class-testimonial.php' );
		require_once( __DIR__ . '/widgets/class-testimonial2.php' );
		require_once( __DIR__ . '/widgets/class-blog-grid.php' );
		require_once( __DIR__ . '/widgets/class-feature-box.php' );
		require_once( __DIR__ . '/widgets/class-pricing-plan.php' );
		require_once( __DIR__ . '/widgets/class-tld-price.php' );
		require_once( __DIR__ . '/widgets/class-vps-hosting.php' );
		require_once( __DIR__ . '/widgets/class-price-table2.php' );
		require_once( __DIR__ . '/widgets/class-price-table3.php' );
		require_once( __DIR__ . '/widgets/class-price-table4.php' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Axiohost Addon Files
		$this->include_axiohost_addon_files();


		// Register Home1 Slider Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostHome1Slider() );
		
		// Register Axiohost Title  Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostTitle() );
		
		// Register Axiohost Service Box Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostService() );
		
		// Register Axiohost Price Table1 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostPriceTable1() );
		
		// Register Axiohost Testimonial Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostTestimonial() );
		
		// Register Axiohost Blog Grid Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostBlogGrid() );
		
		// Register Axiohost Testimonial2 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostTestimonial2() );
		
		
		// Register Axiohost Feature Box Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostFeatureBox() );
		
		// Register Axiohost Pricing Plan2 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostPricingPlan() );
		
		// Register Axiohost TLD Plan Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostTLDPlan() );
		
		// Register Axiohost pricing VPS Hosting Plan Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostVPSHostingPlan() );
		
		// Register Axiohost Pricing Table 2 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostPriceTable2() );
		
		// Register Axiohost Pricing Table3 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostPriceTable3() );
		
		// Register Axiohost Pricing Table4 Addon
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\AxiohostPriceTable4() );
		
		
		
	}
    public function add_elementor_widget_categories( $elements_manager ) {

    	$elements_manager->add_category(
    		'axiohost-addons',
    		[
    			'title' => __( 'Axiohost Addons', 'axiohost-elementor-addons' ),
    			'icon' => 'fa fa-plug',
    		]
    	);
    
    }
	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

		// Register widget style
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		
		//Register Widget Category
        add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories'] );
		
	}
}

// Instantiate Plugin Class
AxiohostElementorAddonsMain::instance();

