<?php

/**
 * @package ThemeixPlugins
 */
/*
Plugin Name: Levert Core
Plugin URI: https://themeix.com/plugins/levert-core
Description: This is plugin use for Themeix levert WordPress theme.
Version: 1.0.3
Author: Themeix
Author URI: https://themeix.com/
License: GPLv2 or later 
Text Domain: levert-core
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/

if (!defined('ABSPATH')) {
	die;
}


class ThemeixLevertPlugin
{
	function add_action_hook()
	{
		add_action('init', array($this, 'levert_post_type'));
		add_action('init', array($this, 'levert_register_custom_taxonomies'));
		add_shortcode('levert_social_share', array($this, 'levert_social_sharing_buttons'));
		add_action('show_user_profile', array($this, 'levert_extra_user_profile_fields'));
		add_action('edit_user_profile', array($this, 'levert_extra_user_profile_fields'));
		add_action('personal_options_update', array($this, 'levert_save_extra_user_profile_fields'));
		add_action('edit_user_profile_update', array($this, 'levert_save_extra_user_profile_fields'));
	}

	//activation
	function activation()
	{
		//flush rewrite rules
		flush_rewrite_rules();
	}

	//Deactivation
	function deactivation()
	{ }

	/*
* Creating a function to create our CPT
*/

	function levert_post_type()
	{
		// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => esc_html__('Services', 'levert-core'),
			'singular_name'       => esc_html__('Service', 'levert-core'),
			'menu_name'           => esc_html__('Services', 'levert-core'),
			'parent_item_colon'   => esc_html__('Parent Service', 'levert-core'),
			'all_items'           => esc_html__('All Services', 'levert-core'),
			'view_item'           => esc_html__('View Service', 'levert-core'),
			'add_new_item'        => esc_html__('Add New Service', 'levert-core'),
			'add_new'             => esc_html__('Add New', 'levert-core'),
			'edit_item'           => esc_html__('Edit Service', 'levert-core'),
			'update_item'         => esc_html__('Update Service', 'levert-core'),
			'search_items'        => esc_html__('Search Service', 'levert-core'),
			'not_found'           => esc_html__('Not Found', 'levert-core'),
			'not_found_in_trash'  => esc_html__('Not found in Trash', 'levert-core'),
		);

		// Set other options for Custom Post Type

		$args = array(
			'label'               => esc_html__('Services', 'levert-core'),
			'description'         => esc_html__('Service news and reviews', 'levert-core'),
			'labels'              => $labels,
			'supports'            => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields',),
			'taxonomies'          => array('genres'),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'menu_icon'           => 'dashicons-admin-generic',
			'capability_type'     => 'post',
			'show_in_rest' => true,

		);

		// Registering your Custom Post Type  
		register_post_type('service', $args);
	}

	function levert_register_custom_taxonomies()
	{
		register_taxonomy( 'location', 'service', array(
		"hierarchical" => true,
		"label" => "Display Location",
		"singular_label" => "Display Location",
		'query_var' => true,
		'rewrite' => array( 'slug' => 'location', 'with_front' => false ),
		'public' => true,
		'show_ui' => true,
		'show_tagcloud' => true,
		'_builtin' => false,
		'show_in_nav_menus' => false,
		'show_in_rest' => true

		));
	}
	


	//Levert Social Share Buttons
	function get_the_post_thumbnail_src($img)
	{
		return (preg_match('~\bsrc="([^"]++)"~', $img, $matches)) ? $matches[1] : '';
	}

	function levert_social_sharing_buttons()
	{
		global $post;
		if (is_singular()) {

			// Get current page URL 
			$lvrt_url = urlencode(get_permalink());

			// Get current page title
			$lvrt_title = str_replace(' ', '%20', get_the_title());

			// Get Post Thumbnail for pinterest
			$lvrt_thumb = get_the_post_thumbnail_url();

			// Construct sharing URL without using any script
			$twitterURL = 'https://twitter.com/intent/tweet?text=' . $lvrt_title . '&amp;url=' . $lvrt_url . '&amp;via=wpvkp';
			$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $lvrt_url;
			$bufferURL = 'https://bufferapp.com/add?url=' . $lvrt_url . '&amp;text=' . $lvrt_title;
			$whatsappURL  = 'whatsapp://send?text=' . $lvrt_title . ' ' . $lvrt_url;
			$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $lvrt_url . '&amp;title=' . $lvrt_title;

			if (!empty($lvrt_thumb)) {
				$pinterestURL = 'https://pinterest.com/pin/create/button/?url=' . $lvrt_url . '&amp;media=' . $lvrt_thumb[0] . '&amp;description=' . $lvrt_title;
			} else {
				$pinterestURL = 'https://pinterest.com/pin/create/button/?url=' . $lvrt_url . '&amp;description=' . $lvrt_title;
			}

			// Based on popular demand added Pinterest too
			$pinterestURL = 'https://pinterest.com/pin/create/button/?url=' . $lvrt_url . '&amp;media=' . $lvrt_thumb[0] . '&amp;description=' . $lvrt_title;

			?>

			<ul class="share-link-social list-inline m-0">
				<li class="list-inline-item">
					<a class="pinterest" href="<?php echo esc_url($pinterestURL) ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
						<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 500 600" style="enable-background:new 0 0 511.998 511.998;" xml:space="preserve">
							<path style="fill:#ffffff;" d="M405.017,52.467C369.774,18.634,321.001,0,267.684,0C186.24,0,136.148,33.385,108.468,61.39  c-34.114,34.513-53.675,80.34-53.675,125.732c0,56.993,23.839,100.737,63.76,117.011c2.68,1.098,5.377,1.651,8.021,1.651  c8.422,0,15.095-5.511,17.407-14.35c1.348-5.071,4.47-17.582,5.828-23.013c2.906-10.725,0.558-15.884-5.78-23.353  c-11.546-13.662-16.923-29.817-16.923-50.842c0-62.451,46.502-128.823,132.689-128.823c68.386,0,110.866,38.868,110.866,101.434  c0,39.482-8.504,76.046-23.951,102.961c-10.734,18.702-29.609,40.995-58.585,40.995c-12.53,0-23.786-5.147-30.888-14.121  c-6.709-8.483-8.921-19.441-6.222-30.862c3.048-12.904,7.205-26.364,11.228-39.376c7.337-23.766,14.273-46.213,14.273-64.122  c0-30.632-18.832-51.215-46.857-51.215c-35.616,0-63.519,36.174-63.519,82.354c0,22.648,6.019,39.588,8.744,46.092  c-4.487,19.01-31.153,132.03-36.211,153.342c-2.925,12.441-20.543,110.705,8.618,118.54c32.764,8.803,62.051-86.899,65.032-97.713  c2.416-8.795,10.869-42.052,16.049-62.495c15.817,15.235,41.284,25.535,66.064,25.535c46.715,0,88.727-21.022,118.298-59.189  c28.679-37.02,44.474-88.618,44.474-145.282C457.206,127.983,438.182,84.311,405.017,52.467z" />
							<g></g><g></g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g><g> </g>
						</svg>
					</a>
				</li>
				<li class="list-inline-item">
					<a class="facebook" href="<?php echo esc_url($facebookURL); ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
						<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
							<path fill="currentColor" d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
						</svg>
					</a>
				</li>
				<li class="list-inline-item">
					<a class="whatsapp" style="background-color:#7AD06D" href="<?php echo esc_url($whatsappURL); ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
						<svg width="16" height="16" version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 320 512" style="enable-background:new 0 0 418.135 418.135;" xml:space="preserve">
							<g>
								<path style="fill:#fff;" d="M198.929,0.242C88.5,5.5,1.356,97.466,1.691,208.02c0.102,33.672,8.231,65.454,22.571,93.536
                        L2.245,408.429c-1.191,5.781,4.023,10.843,9.766,9.483l104.723-24.811c26.905,13.402,57.125,21.143,89.108,21.631
                        c112.869,1.724,206.982-87.897,210.5-200.724C420.113,93.065,320.295-5.538,198.929,0.242z M323.886,322.197
                        c-30.669,30.669-71.446,47.559-114.818,47.559c-25.396,0-49.71-5.698-72.269-16.935l-14.584-7.265l-64.206,15.212l13.515-65.607
                        l-7.185-14.07c-11.711-22.935-17.649-47.736-17.649-73.713c0-43.373,16.89-84.149,47.559-114.819
                        c30.395-30.395,71.837-47.56,114.822-47.56C252.443,45,293.218,61.89,323.887,92.558c30.669,30.669,47.559,71.445,47.56,114.817
                        C371.446,250.361,354.281,291.803,323.886,322.197z" />
								<path style="fill:#fff;" d="M309.712,252.351l-40.169-11.534c-5.281-1.516-10.968-0.018-14.816,3.903l-9.823,10.008
                        c-4.142,4.22-10.427,5.576-15.909,3.358c-19.002-7.69-58.974-43.23-69.182-61.007c-2.945-5.128-2.458-11.539,1.158-16.218
                        l8.576-11.095c3.36-4.347,4.069-10.185,1.847-15.21l-16.9-38.223c-4.048-9.155-15.747-11.82-23.39-5.356
                        c-11.211,9.482-24.513,23.891-26.13,39.854c-2.851,28.144,9.219,63.622,54.862,106.222c52.73,49.215,94.956,55.717,122.449,49.057
                        c15.594-3.777,28.056-18.919,35.921-31.317C323.568,266.34,319.334,255.114,309.712,252.351z" />
							</g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
							<g></g>
						</svg>
					</a>
				</li>
				<li class="list-inline-item">
					<a class="linkedin" href="<?php echo esc_url($linkedInURL); ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
						<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
							<path fill="currentColor" d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path>
						</svg>
					</a>
				</li>
				<li class="list-inline-item">
					<a class="twitter" href="<?php echo esc_url($twitterURL); ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
						<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
							<path fill="currentColor" d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path>
						</svg>
					</a>
				</li>
				<li class="list-inline-item">
					<a class="buffer" style="background-color:#000" href="<?php echo esc_url($bufferURL); ?>" rel="noopener" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;">
					<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_2" x="0px"
						y="0px" viewBox="0 0 350.001 350.001" style="enable-background:new 0 0 350.001 350.001;" xml:space="preserve">
						<g>
							<path style="fill:#fff;"
								d="M14.092,88.77L172.1,164.826c1.833,0.882,3.969,0.882,5.802,0L335.91,88.769   c5.051-2.429,5.051-9.621,0-12.051L177.9,0.662c-1.832-0.882-3.968-0.882-5.801,0L14.092,76.719   C9.041,79.149,9.041,86.34,14.092,88.77z" />
							<path style="fill:#fff;"
								d="M14.092,181.025L172.1,257.082c1.833,0.882,3.969,0.882,5.802,0l158.008-76.057   c5.051-2.429,5.051-9.621,0-12.053l-33.336-16.044l-105.881,50.962c-6.726,3.236-14.228,4.946-21.692,4.946   s-14.964-1.71-21.702-4.951L47.43,152.925l-33.339,16.047C9.041,171.405,9.041,178.596,14.092,181.025z" />
							<path style="fill:#fff;"
								d="M335.91,261.229l-33.336-16.047l-105.881,50.965c-6.726,3.236-14.228,4.946-21.692,4.946   s-14.964-1.71-21.702-4.951L47.43,245.183L14.091,261.23c-5.051,2.432-5.051,9.621,0,12.053l158.008,76.057   c1.833,0.882,3.969,0.882,5.802,0l158.008-76.057C340.961,270.85,340.961,263.66,335.91,261.229z" /></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g>
					</svg>
					</a>
				</li>
			</ul>

		<?php
				}
			}


			function levert_extra_user_profile_fields($user)
			{ ?>
		<h3><?php echo esc_html__('Extra profile information', 'churel'); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="facebook"><?php echo esc_html__('Facebook', 'churel'); ?></label></th>
				<td>
					<input type="text" name="facebook" id="facebook" value="<?php echo esc_attr(get_the_author_meta('facebook', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your facebook url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="twitter"><?php echo esc_html__('Twitter', 'churel'); ?></label></th>
				<td>
					<input type="text" name="twitter" id="twitter" value="<?php echo esc_attr(get_the_author_meta('twitter', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your twitter url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="instagram"><?php echo esc_html__('Instagram', 'churel'); ?></label></th>
				<td>
					<input type="text" name="instagram" id="instagram" value="<?php echo esc_attr(get_the_author_meta('instagram', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your instagram url.', 'churel'); ?></span>
				</td>
			</tr>
		</table>
<?php }

	function levert_save_extra_user_profile_fields($user_id)
	{
		if (!current_user_can('edit_user', $user_id)) {
			return false;
		}
		update_user_meta($user_id, 'facebook', $_POST['facebook']);
		update_user_meta($user_id, 'twitter', $_POST['twitter']);
		update_user_meta($user_id, 'instagram', $_POST['instagram']);
	}
}
if (class_exists('ThemeixLevertPlugin')) {
	$LevertPlugin = new ThemeixLevertPlugin();
	$LevertPlugin->add_action_hook();
}


final class LevertElementorAddonsPlugin
{

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.2.0
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.4.0';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct()
	{

		// Load translation
		add_action('init', array($this, 'i18n'));

		// Init Plugin
		add_action('plugins_loaded', array($this, 'init'));
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function i18n()
	{
		load_plugin_textdomain('levert-core');
	}

	/**
	 * Initialize the plugin
	 *
	 * Validates that Elementor is already loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed include the plugin class.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function init()
	{

		// Check if Elementor installed and activated
		if (!did_action('elementor/loaded')) {
			add_action('admin_notices', array($this, 'admin_notice_missing_main_plugin'));
			return;
		}

		// Check for required Elementor version
		if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
			add_action('admin_notices', array($this, 'admin_notice_minimum_elementor_version'));
			return;
		}

		// Check for required PHP version
		if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
			add_action('admin_notices', array($this, 'admin_notice_minimum_php_version'));
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once('plugin.php');
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_missing_main_plugin()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'levert-core'),
			'<strong>' . esc_html__('Levert Elementor Addons', 'levert-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'levert-core') . '</strong>'
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'levert-core'),
			'<strong>' . esc_html__('Levert Elementor Addons', 'levert-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'levert-core') . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'levert-core'),
			'<strong>' . esc_html__('Levert Elementor Addons', 'levert-core') . '</strong>',
			'<strong>' . esc_html__('PHP', 'levert-core') . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}
}



// Instantiate Elementor_Post_Grid.
new LevertElementorAddonsPlugin();



//Activation Hook
register_activation_hook(__FILE__, array($LevertPlugin, 'activation'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($LevertPlugin, 'deactivation'));
