(function ($) {
    "use strict";
    $('.card-header button').on('click', function (e) {
        $('.accordion-icon-active').toggleClass('active');
        $('.accordion-icon-collapse').toggleClass('collapse');
    });

}(jQuery));
