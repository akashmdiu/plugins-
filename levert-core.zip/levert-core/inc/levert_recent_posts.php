<?php
// Creating the widget 
class levert_widget extends WP_Widget
{

    function __construct()
    {
        parent::__construct(

            // Base ID of your widget
            'levert_widget',

            // Widget name will appear in UI
            esc_html__('Levert Recent Post', 'levert'),

            // Widget description
            array('description' => esc_html__('Levert recent post widget', 'levert'),)
        );
    }

    // Creating widget front-end

    public function widget($args, $instance)
    {
        $posts_per_page = 3;
        $title = apply_filters('widget_title', $instance['title']);
        $posts_per_page = apply_filters('widget_posts_per_page', $instance['posts_per_page']);

        // before and after widget arguments are defined by themes
        echo $args['before_widget'];
        if (!empty($title))
            echo $args['before_title'] . $title . $args['after_title'];

        $lvrt_query = new WP_Query(array(
            'post_type' => 'post',
            'posts_per_page' => $posts_per_page,
            'post__not_in' => get_option("sticky_posts")
        ));

        if ($lvrt_query->have_posts()) : ?>
            <ul>
                <?php while ($lvrt_query->have_posts()) : $lvrt_query->the_post(); ?>
                    <li>
                        <div class="blog-style post-has-no-image d-flex">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="post-image">
                                    <?php the_post_thumbnail(); ?>
                                </div>
                            <?php endif; ?>
                            <div class="blog-content">
                                <div class="author-info "><?php echo get_avatar(get_the_author_meta('ID'), 30); ?><a href="<?php echo esc_url(home_url() . '/author/' . get_the_author_meta('user_nicename')); ?>" class="small"><?php the_author(); ?></a></div>

                                <?php if (get_the_title()) : ?>
                                    <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                <?php endif; ?>

                            </div>
                        </div>
                    </li>
                <?php endwhile; ?>

            </ul>
        <?php endif;


                echo $args['after_widget'];
            }

            // Widget Backend 
            public function form($instance)
            {
                if (isset($instance['title'])) {
                    $title = $instance['title'];
                } else {
                    $title = esc_html__('Levert Recent Post', 'levert');
                }

                if (isset($instance['posts_per_page'])) {
                    $posts_per_page = $instance['posts_per_page'];
                } else {
                    $posts_per_page = 3;
                }
                
                // Widget admin form
                ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('posts_per_page'); ?>"><?php _e('Posts per page:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('posts_per_page'); ?>" name="<?php echo $this->get_field_name('posts_per_page'); ?>" type="text" value="<?php echo esc_attr($posts_per_page); ?>" />
        </p>
<?php
    }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['posts_per_page'] = (!empty($new_instance['posts_per_page'])) ? strip_tags($new_instance['posts_per_page']) : '';
        return $instance;
    }

    // Class levert_widget ends here
}


// Register and load the widget
function wpb_load_widget()
{
    register_widget('levert_widget');
}
add_action('widgets_init', 'wpb_load_widget');
