<?php
namespace LevertElementorAddons;

/**
 * Class LevertElementorAddonsMain
 *
 * Main Plugin class
 * @since 1.2.0
 */


class LevertElementorAddonsMain {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * widget_style
	 *
	 * Load main style files.
	 *
	 * @since 1.0.0
	 * @access public
	 */

	public function widget_styles() {
	    //css style
		wp_register_style( 'slick', plugins_url( '/assets/css/slick.css', __FILE__ ) );
		wp_enqueue_style( 'slick' );

	    //app core style
		wp_register_style( 'app-core', plugins_url( '/assets/css/app.css', __FILE__ ) );
		wp_enqueue_style( 'app-core' );
		
		
	}

	public function widget_scripts() {
		
	    //Enqueue Venobox
		wp_register_script( 'jquery', 'https://releases.jquery.com/git/jquery-3.x-git.min.js' );
		wp_enqueue_script( 'jquery' );

		//Levert Custom JS
		wp_register_script( 'levert-custom', plugins_url( '/assets/js/custom.js', __FILE__ ) );
		wp_enqueue_script( 'levert-custom' );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function include_levert_addon_files() {
		require_once( __DIR__ . '/widgets/class-blog-grid.php' );
		require_once( __DIR__ . '/widgets/class-team-member.php' );
		require_once( __DIR__ . '/widgets/class-testimonial.php' );
		require_once( __DIR__ . '/widgets/class-masonry-gallery.php' );
		require_once( __DIR__ . '/widgets/class-accordion.php' );
		require_once( __DIR__ . '/widgets/class-breadcrumb.php' );
	}

	
    
	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Levert Addon Files
		$this->include_levert_addon_files();

		// Register Blog Grid Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LevertBlogGrid() );

		// Register Team Member Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LevertTeamMember() );

		// Register Testimonial Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LevertTestimonial() );

		// Register Masonry Gallery Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\MasonryGallery() );

		// Register Levert Accordion Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LevertAccordion() );

		// Register BreadCrumb Widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LevertBreadCrumb() );
		
	}

	public function add_elementor_widget_categories( $elements_manager ) {

    	$elements_manager->add_category(
    		'levert-addons',
    		[
    			'title' => __( 'Levert Addons', 'levert-core' ),
    			'icon' => 'fa fa-plug',
    		] 
    	);
    
    }
	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

		// Register widget style
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );

		// Register widget style
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		//Register Widget Category
        add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories'] );
		
	}
}

// Instantiate Plugin Class
LevertElementorAddonsMain::instance();


