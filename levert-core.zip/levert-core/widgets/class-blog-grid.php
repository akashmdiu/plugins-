<?php

namespace LevertElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */

function post_categories()
{

    $terms = get_terms(array(
        'taxonomy' => 'category',
        'hide_empty' => false,
    ));

    $term_name = wp_list_pluck($terms, 'name', 'term_id');

    return $term_name;
}

function get_lvrt_post_type()
{
    $lvrt_post_type = get_post_types(
        array(
            '_builtin' => true,
            'public' => true
        ),
    );
    $lvrt_post_type['service'] = "service";
    return $lvrt_post_type;
}



class LevertBlogGrid extends Widget_Base
{

    public function get_name()
    {
        return 'blog-grid';
    }

    public function get_title()
    {
        return __('Blog Grid', 'levert-core');
    }

    public function get_icon()
    {
        return 'eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['levert-addons'];
    }
    protected function register_controls()
    {

        $this->start_controls_section(
            'lvrt_blog_query',
            [
                'label' => esc_html__('Query', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'lvrt_post_type',
            [
                'label' => esc_html__('Post Type', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => get_lvrt_post_type(),
                'label_block' => true
            ]
        );
        $this->add_control(
            'post_category',
            [
                'label' => esc_html__('Categories', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => post_categories(),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post_order',
            [
                'label' => esc_html__('Order', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'ASC'  => esc_html__('ASC', 'levert-core'),
                    'DSC' => esc_html__('DSC', 'levert-core'),
                ],
                'default' => esc_html__('DSC', 'levert-core'),
            ]
        );
        $this->add_control(
            'post_order_by',
            [
                'label' => esc_html__('Order By', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'title'  => esc_html__('Title', 'levert-core'),
                    'name' => esc_html__('Name', 'levert-core'),
                    'id' => esc_html__('ID', 'levert-core'),
                    'date' => esc_html__('Date', 'levert-core'),
                ],
                'default' => esc_html__('title', 'levert-core'),
            ]
        );

        $this->add_control(
            'title_words_limit',
            [
                'label' => esc_html__('Title Words Limit', 'levert-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__('8', 'levert-core'),
            ]
        );

        $this->add_control(
            'lvrt_post_excerpt_limit',
            [
                'label' => esc_html__('Post Excerpt Limit', 'levert-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__('30', 'levert-core'),
            ]
        );

        $this->add_control(
            'post_per_page',
            [
                'label' => esc_html__('Post Per Page', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('6', 'levert-core'),
                'placeholder' => esc_html__('Input post per page', 'levert-core'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'lvrt_blog_options',
            [
                'label' => esc_html__('Options', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'lvrt_blog_style',
            [
                'label' => esc_html__('Blog Style', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__('Blog Style 1', 'levert-core'),
                    '2'  => esc_html__('Blog Style 2', 'levert-core'),
                ],
                'default' => esc_html__('1', 'levert-core'),
            ]
        );

        $this->add_control(
            'lvrt_post_per_row',
            [
                'label' => __('Post Per Row', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '6'  => __('2', 'levert-core'),
                    '4' => __('3', 'levert-core'),
                    '3' => __('4', 'levert-core'),
                    '2' => __('6', 'levert-core'),
                ],
            ]
        );

        $this->add_control(
            'lvrt_post_meta',
            [
                'label' => esc_html__('Post Meta', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'levert-core'),
                'label_off' => esc_html__('Hide', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'lvrt_post_readmore',
            [
                'label' => esc_html__('Post Readmore', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'levert-core'),
                'label_off' => esc_html__('Hide', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'lvrt_post_readmore_text',
            [
                'label' => esc_html__('Post Readmore Text', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'levert-core'),
            ]
        );

        $this->add_control(
            'post_pagination',
            [
                'label' => esc_html__('Pagination', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'levert-core'),
                'label_off' => esc_html__('Hide', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'lvrt_pagination_align',
            [
                'label' => esc_html__('Pagination Alignment', 'levert-core'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'levert-core'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'levert-core'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'levert-core'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );
        $this->add_control(
			'post_pagination_spcaing',
			[
				'label' => esc_html__('Spacing', 'levert-core'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .lvrt-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);


        $this->end_controls_section();


        //Style Tab
        $this->start_controls_section(
            'post_style',
            [
                'label' => esc_html__('Style', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'lvrt_blog_title',
            [
                'label' => __('Title', 'levert-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'lvrt_blog_title_color',
            [
                'label' => __('Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .news-content h4 a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'lvrt_post_title_typography',
                'label' => __('Typography', 'levert-core'),
                'selector' => '{{WRAPPER}} .news-content h4 a',
            ]
        );
        $this->add_control(
            'lvrt_blog_meta_data',
            [
                'label' => __('Meta Data', 'levert-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'lvrt_blog_metadata_color',
            [
                'label' => __('Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .news-post .news-content .meta-data li small' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'lvrt_blog_metadata_bg_color',
            [
                'label' => __('Background Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .news-post .news-content .meta-data li' => 'background-color: {{VALUE}}!important',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'lvrt_post_metadata_typography',
                'label' => __('Typography', 'levert-core'),
                'selector' => '{{WRAPPER}} .news-post .news-content .meta-data li small',
            ]
        );


        //Excerpt Style
        $this->add_control(
            'lvrt_blog_excerpt',
            [
                'label' => __('Post Excerpt', 'levert-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'lvrt_blog_excerpt_color',
            [
                'label' => __('Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .news-content .post-excerpt' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'lvrt_post_excerpt_typography',
                'label' => __('Typography', 'levert-core'),
                'selector' => '{{WRAPPER}} .news-content .post-excerpt',
            ]
        );

        //Readmore Style
        $this->add_control(
            'lvrt_blog_readmore',
            [
                'label' => __('Post Readmore', 'levert-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'lvrt_blog_readmore_color',
            [
                'label' => __('Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .news-content .read-more-btn' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'lvrt_post_readmore_typography',
                'label' => __('Typography', 'levert-core'),
                'selector' => '{{WRAPPER}} .news-content .read-more-btn',
            ]
        );

        //Pagination style 
        $this->add_control(
            'post_title_style',
            [
                'label' => esc_html__('Pagination', 'levert-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'lvrt_pagination_color',
            [
                'label' => esc_html__('Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'lvrt_pagination_current_color',
            [
                'label' => esc_html__('Current Page Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'lvrt_pagination_bg_color',
            [
                'label' => esc_html__('Background Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'lvrt_pagination_bg_current__color',
            [
                'label' => esc_html__('Background Current Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'lvrt_pagination_typography',
                'label' => esc_html__('Typography', 'levert-core'),
                'selector' => '{{WRAPPER}} .pagination .nav-links .page-numbers',
            ]
        );


        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    
    protected function render()
    {
        $settings = $this->get_settings_for_display(); ?>



        <div class="row lvrt-normalize">
            <?php
                    //$x = 0;
                    $posts_per_page = $settings['post_per_page'];
                    $order = $settings['post_order'];
                    $post_style = $settings['lvrt_blog_style'];
                    // $layout1 = $settings['style_one_layout'];
                    // $layout2 = $settings['style_two_layout'];
                    $words_limit = $settings['title_words_limit'];
                    $posts_per_row = $settings['lvrt_post_per_row'];
                    $posts_type = $settings['lvrt_post_type'];
                    $posts_meta = $settings['lvrt_post_meta'];

                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    if (is_front_page()) {
                        $paged = (get_query_var('page')) ? get_query_var('page') : 1;
                    }

                    $query = new \WP_Query(array(
                        'post_type' =>  $posts_type,
                        'posts_per_page' => $posts_per_page,
                        'order' => "$order",
                        'post_status' => 'publish',
                        'category__in' => $settings['post_category'],
                        'paged' => $paged

                    ));
                    if ($query->have_posts()) : ?>
                        <?php while ($query->have_posts()) : $query->the_post(); 
                            $img_url = 'https://d33wubrfki0l68.cloudfront.net/b382a8940e46dc8555da2bce6cc3dd06d4de8100/30079/assets/images/service/5.svg';

                            if(class_exists('ACF') && get_field('service_icon')){
                                $img_url = get_field('service_icon');
                            }
                        ?>
                            <?php if($post_style == 1): ?>
                                <div class="col-md-6 col-lg-<?php echo esc_html($posts_per_row); ?>">

                                    <div class="blog-style mb-3 aos-init aos-animate" data-aos="fade">
                                        <div class="blog-image">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <?php the_post_thumbnail(); ?>
                                            <?php else : ?>
                                                <img src="<?php echo esc_url(LEVERT_IMG_URL . "/prev.png"); ?>" alt="<?php the_title(); ?>" />
                                            <?php endif; ?>
                                        </div>
                                        <div class="blog-content">

                                            <div class="author-info"><?php echo get_avatar(get_the_author_meta('ID'), 30); ?><a href="<?php echo esc_url(home_url() . '/author/' . get_the_author_meta('user_nicename')); ?>" class="small text-white"><?php the_author(); ?></a></div>

                                            <h4 class="my-3"><a class="hover-title text-white" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

                                            <?php if ($settings['lvrt_post_readmore']) : ?>
                                                <a href="<?php the_permalink(); ?>" class="read-more">
                                                    <?php echo esc_html($settings['lvrt_post_readmore_text']); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                            <?php else: ?>
                                <div class="col-md-6 col-lg-<?php echo esc_html($posts_per_row); ?>">
                                    <div class="service-box mb-4 mb-lg-7 aos-init aos-animate" data-aos="fade-up">
                                        <div class="service-icon"><img
                                                src="<?php echo esc_url($img_url); ?>"
                                                alt="title"></div>
                                        <div class="service-content">
                                            <h4 class="mb-4"><?php the_title(); ?></h4>
                                            <div class="mb-4">
                                                <?php the_excerpt(  ); ?>
                                            </div>
                                            <a href="<?php the_permalink(); ?>" class="read-more"> <?php echo esc_html($settings['lvrt_post_readmore_text']); ?></a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                        <?php endwhile; ?>

                        <?php $total_pages = $query->max_num_pages;
                            $current_page = max(1, get_query_var('paged'));

                            if (is_front_page()) :
                                $current_page = max(1, get_query_var('page'));
                            endif;
                    endif; ?>

        </div>

    
        <?php if ($settings['post_pagination'] == 'yes') :
            echo '<div class="row pagination" style="text-align: ' . $settings['lvrt_pagination_align'] . '!important"> 
            <div class="nav-links col-md-12 lvrt-pagination">';
            echo paginate_links(array(
                'total' => $total_pages,
                'current' => $current_page,
                'prev_text'    => esc_html__('prev'),
                'next_text'    => esc_html__('next'),
            ));
            echo '</div></div>';
        endif;
    }
}
