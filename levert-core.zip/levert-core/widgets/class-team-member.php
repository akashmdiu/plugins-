<?php



namespace LevertElementorAddons\Widgets;



use Elementor\Widget_Base;

use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Box_Shadow;

use Elementor\Scheme_Typography;

use Elementor\Scheme_Color;

use Elementor\Group_Control_Image_Size;



if (!defined('ABSPATH')) exit; // Exit if accessed directly


/**

 * @since 1.1.0

 */







class LevertTeamMember extends Widget_Base

{



    public function get_name()

    {

        return 'team-member';
    }



    public function get_title()

    {

        return __('Team Member', 'levert-core');
    }



    public function get_icon()

    {

        return 'eicon-user-circle-o';
    }



    public function get_categories()

    {

        return ['levert-addons'];
    }

    protected function register_controls()

    {



        //Content Tab



        $this->start_controls_section(

            'team_content',

            [

                'label' => __('Team Member', 'levert-core'),

                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,

            ]

        );

        $this->add_control(
            'team_type',
            [
                'label' => esc_html__('Team Type', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'carousel',
                'options' => [
                    'carousel'  => esc_html__('carousel', 'levert-core'),
                    'column' => esc_html__('Column', 'levert-core'),
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();



        $repeater->add_control(

            'member_image',

            [

                'label' => __('Choose Image', 'levert-core'),

                'type' => \Elementor\Controls_Manager::MEDIA,

                'default' => [

                    'url' => \Elementor\Utils::get_placeholder_image_src(),

                ],

            ]

        );



        $repeater->add_control(

            'member_name',

            [

                'label' => __('Name', 'levert-core'),

                'type' => Controls_Manager::TEXT,

                'dynamic' => [

                    'active' => true,

                ],

                'default' => __('John Maroko', 'levert-core'),

                'placeholder' => __('Enter mamber name', 'levert-core'),

                'label_block' => true,

            ]

        );

        $repeater->add_control(

            'member_designation',

            [

                'label' => __('Designation', 'levert-core'),

                'type' => Controls_Manager::TEXTAREA,

                'dynamic' => [

                    'active' => true,

                ],

                'default' => __('Cheif Product Officer at Chicago.k', 'levert-core'),

                'placeholder' => __('Enter member designation', 'levert-core'),

                'separator' => 'none',

                'rows' => 4,

            ]

        );

        $repeater->add_control(

            'website_link',

            [

                'label' => __('Website Link', 'levert-core'),

                'type' => Controls_Manager::URL,

                'label_block' => true,

                'default' => [

                    'is_external' => 'true',

                ],

                'placeholder' => __('https://your-link.com', 'levert-core'),

            ]

        );

        $repeater->add_control(

            'facebook_link',

            [

                'label' => __('Facebook Link', 'levert-core'),

                'type' => Controls_Manager::URL,

                'label_block' => true,

                'default' => [

                    'is_external' => 'true',

                ],

                'placeholder' => __('https://your-link.com', 'levert-core'),

            ]

        );

        $repeater->add_control(

            'linkedin_link',

            [

                'label' => __('Linkedin Link', 'levert-core'),

                'type' => Controls_Manager::URL,

                'label_block' => true,

                'default' => [

                    'is_external' => 'true',

                ],

                'placeholder' => __('https://your-link.com', 'levert-core'),

            ]

        );

        $repeater->add_control(

            'instagram_link',

            [

                'label' => __('Instagram Link', 'levert-core'),

                'type' => Controls_Manager::URL,

                'label_block' => true,

                'default' => [

                    'is_external' => 'true',

                ],

                'placeholder' => __('https://your-link.com', 'levert-core'),

            ]

        );



        $this->add_control(

            'member_list',

            [

                'label' => __('Member List', 'levert-core'),

                'type' => \Elementor\Controls_Manager::REPEATER,

                'fields' => $repeater->get_controls(),

                'default' => [

                    [

                        'member_name' => __('Wade Warren'),

                        'member_designation' => __('CEO, Founder', 'levert-core'),

                    ],

                    [

                        'member_name' => __('Jerome Bell', 'levert-core'),

                        'member_designation' => __('Principle Engineer', 'levert-core'),

                    ],

                ],

                'title_field' => '{{{ member_name }}}',

            ]

        );





        $this->end_controls_section();



        $this->start_controls_section(

            'setting_section',

            [

                'label' => __('Slider Settings', 'plugin-name'),

                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,

            ]

        );



        $this->add_control(

            'loop',

            [

                'label' => __('Loop?', 'levert-core'),

                'type' => \Elementor\Controls_Manager::SWITCHER,

                'label_on' => __('Yes', 'levert-core'),

                'label_off' => __('No', 'levert-core'),

                'return_value' => 'yes',

                'default' => 'yes',

            ]

        );

        $this->add_control(

            'arrows',

            [

                'label' => __('Show arrows?', 'levert-core'),

                'type' => \Elementor\Controls_Manager::SWITCHER,

                'label_on' => __('Show', 'levert-core'),

                'label_off' => __('Hide', 'levert-core'),

                'return_value' => 'yes',

                'default' => 'yes',

            ]

        );





        $this->add_control(

            'autoplay',

            [

                'label' => __('Autoplay?', 'levert-core'),

                'type' => \Elementor\Controls_Manager::SWITCHER,

                'label_on' => __('Yes', 'levert-core'),

                'label_off' => __('No', 'levert-core'),

                'return_value' => 'yes',

                'default' => 'yes',

            ]

        );



        $this->add_control(

            'autoplay_time',

            [

                'label' => __('Autoplay Time', 'levert-core'),

                'type' => \Elementor\Controls_Manager::TEXT,

                'default' => '1000',

                'condition' => [

                    'autoplay' => 'yes',

                ],

            ]

        );



        $this->end_controls_section();



        //Style Tab

        $this->start_controls_section(

            'member_style',

            [

                'label' => __('Style', 'levert-core'),

                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]

        );

        $this->add_control(

            'name_style',

            [

                'label' => __('Name', 'levert-core'),

                'type' => \Elementor\Controls_Manager::HEADING,

                'separator' => 'before',

            ]

        );



        $this->add_control(

            'name_color',

            [

                'label' => __('Color', 'levert-core'),

                'type' => \Elementor\Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .name-color' => 'color: {{VALUE}}',

                ],

            ]

        );

        $this->add_group_control(

            Group_Control_Typography::get_type(),

            [

                'name' => 'name_typography',

                'label' => __('Typography', 'levert-core'),

                'selector' => '{{WRAPPER}} .name-color',

            ]

        );



        $this->add_control(

            'designation_style',

            [

                'label' => __('Designation', 'levert-core'),

                'type' => \Elementor\Controls_Manager::HEADING,

                'separator' => 'before',

            ]

        );



        $this->add_control(

            'designation_color',

            [

                'label' => __('Color', 'levert-core'),

                'type' => \Elementor\Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .member-designation' => 'color: {{VALUE}}',

                ],

            ]

        );

        $this->add_group_control(

            Group_Control_Typography::get_type(),

            [

                'name' => 'designation_typography',

                'label' => __('Typography', 'levert-core'),

                'selector' => '{{WRAPPER}} .member-designation',

            ]

        );



        $this->add_control(

            'icon_style',

            [

                'label' => __('Icon', 'levert-core'),

                'type' => \Elementor\Controls_Manager::HEADING,

                'separator' => 'before',

            ]

        );



        $this->start_controls_tabs('icon_colors');



        $this->start_controls_tab(

            'icon_colors_normal',

            [

                'label' => __('Normal', 'levert-core'),

            ]

        );



        $this->add_control(

            'icon_color',

            [

                'label' => __('Icon Color', 'levert-core'),

                'type' => Controls_Manager::COLOR,

                'default' => '',

                'selectors' => [

                    '{{WRAPPER}} .social_icon' => 'color: {{VALUE}};',

                ],

            ]

        );



        $this->add_control(

            'icon_bg_color',

            [

                'label' => __('Background Color', 'levert-core'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .team-style .team-content .team-socials li' => 'background-color: {{VALUE}};',

                ],

            ]

        );



        $this->end_controls_tab();



        $this->start_controls_tab(

            'icon_colors_hover',

            [

                'label' => __('Hover', 'levert-core'),

            ]

        );



        $this->add_control(

            'hover_icon_color',

            [

                'label' => __('Icon Color', 'levert-core'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .team-style .team-content .team-socials li:hover .social_icon' => 'color: {{VALUE}};',

                ],

            ]

        );



        $this->add_control(

            'hover_icon_bg_color',

            [

                'label' => __('Background Color', 'levert-core'),

                'type' => Controls_Manager::COLOR,

                'selectors' => [

                    '{{WRAPPER}} .team-style .team-content .team-socials li:hover' => 'background-color: {{VALUE}};',

                ],

            ]

        );

        $this->add_control(

            'hover_transition',

            [

                'label' => __('Hover Transition', 'levert-core'),

                'type' => Controls_Manager::TEXT,

                'selectors' => [

                    '{{WRAPPER}} .team-style .team-content .team-socials li' => 'transition: {{VALUE}};s',

                ],

                'default' => '0.3'

            ]

        );







        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }



    protected function render()

    {

        $settings = $this->get_settings_for_display();



        $member_id = rand(964, 9456986);


        if ($settings['team_type'] == 'carousel') {
            echo ' 

            <div class="swiper-container team-slider-' . $member_id . '">

                <div class="swiper-wrapper">';

            if (is_array($settings['member_list'])) :

                foreach ($settings['member_list'] as $member) {
                    echo '<div class="swiper-slide">

                        <div class="team-box">

                            <div class="team-image">

                                <img src="' . esc_url($member['member_image']['url']) . '" alt="' . esc_attr($member['member_name']) . '">

                            </div>

                            <div class="team-content text-center">

                                <h5>' . esc_html($member['member_name']) . '</h5>

                                <p>' . esc_html($member['member_designation']) . '</p>



                                <ul class="share-social list-inline m-0">

                                    <li class="list-inline-item">

                                        <a href="' . esc_url($member['facebook_link']['url']) . '" rel="noopener" target="_blank">

                                            <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">

                                                <path fill="currentColor"

                                                    d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">

                                                </path>

                                            </svg>

                                        </a>

                                    </li>

                                    <li class="list-inline-item">

                                        <a href="' . esc_url($member['linkedin_link']['url']) . '" rel="noopener" target="_blank">

                                            <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">

                                                <path fill="currentColor"

                                                    d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">

                                                </path>

                                            </svg>

                                        </a>

                                    </li>

                                    <li class="list-inline-item">

                                        <a href="' . esc_url($member['instagram_link']['url']) . '" rel="noopener" target="_blank">

                                            <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">

                                                <path fill="currentColor"

                                                    d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">

                                                </path>

                                            </svg>

                                        </a>

                                    </li>



                                </ul>

                            </div>

                        </div>



                    </div>';
                }

            endif;

            echo '</div></div>';
        } else {
            echo ' 
            <div class="row">';
            if (is_array($settings['member_list'])) {

                foreach ($settings['member_list'] as $member) {
                    echo '<div class="col-md-6 col-lg-4 mb-3">
                    <div class="team-box">
            
                        <div class="team-image">
            
                            <img src="' . esc_url($member['member_image']['url']) . '" alt="' . esc_attr($member['member_name']) . '">
            
                        </div>
            
                        <div class="team-content text-center">
            
                            <h5>' . esc_html($member['member_name']) . '</h5>
            
                            <p>' . esc_html($member['member_designation']) . '</p>
            
                            <ul class="share-social list-inline m-0">
            
                                <li class="list-inline-item">
            
                                    <a href="' . esc_url($member['facebook_link']['url']) . '" rel="noopener" target="_blank">
            
                                        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
            
                                            <path fill="currentColor" d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
            
                                            </path>
            
                                        </svg>
            
                                    </a>
            
                                </li>
            
                                <li class="list-inline-item">
            
                                    <a href="' . esc_url($member['linkedin_link']['url']) . '" rel="noopener" target="_blank">
            
                                        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
            
                                            <path fill="currentColor" d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
            
                                            </path>
            
                                        </svg>
            
                                    </a>
            
                                </li>
            
                                <li class="list-inline-item">
            
                                    <a href="' . esc_url($member['instagram_link']['url']) . '" rel="noopener" target="_blank">
            
                                        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
            
                                            <path fill="currentColor" d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
            
                                            </path>
            
                                        </svg>
            
                                    </a>
            
                                </li>
            
            
            
                            </ul>
            
                        </div>
            
                    </div>
                </div>';
                }
            }
            echo '</div>
            ';
        }

        if ($settings['team_type'] == 'carousel') {
            if (count($settings['member_list']) > 1) {

                if ($settings['arrows'] == 'yes') {

                    $arrows = 'true';
                } else {

                    $arrows = 'false';
                }

                if ($settings['autoplay'] == 'yes') {

                    $autoplay = 'true';
                } else {

                    $autoplay = 'false';
                }

                if ($settings['loop'] == 'yes') {

                    $loop = 'true';
                } else {

                    $loop = 'false';
                }



                echo '<script>



		var swiper = new Swiper(".team-slider-' . $member_id . '", {

		slidesPerView: 3,

		spaceBetween: 24,';

                if ($autoplay == 'true') {

                    echo 'speed: ' . $settings['autoplay_time'] . ',';
                }

                echo ' 

		autoplay:' . $autoplay . ', 

		loop:' . $loop . ', 

		loopedSlides: 50,

		

		navigation: {

			nextEl: ".swiper-button-next",

			prevEl: ".swiper-button-prev",

		}, 

		breakpoints: {

			0: {

			slidesPerView: 1,

			}, 

			700: {

			slidesPerView: 2,

			}, 

			991: {

			slidesPerView: 3,

			},

			1420: {

			slidesPerView: 3,  

			}

		}

		});



    </script>';
            }
        }
    }
}
