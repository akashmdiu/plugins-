<?php

namespace LevertElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */



class LevertBreadCrumb extends Widget_Base
{

    public function get_name()
    {
        return 'lvrt-breadcrumb';
    }

    public function get_title()
    {
        return __('Levert BreadCrumb', 'levert-core');
    }

    public function get_icon()
    {
        return 'eicon-product-breadcrumbs';
    }

    public function get_categories()
    {
        return ['levert-addons'];
    }
    protected function register_controls()
    {

        $this->start_controls_section(
            'accordion_content_tab',
            [
                'label' => __('Levert BreadCrumb', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'breadcrumb_typography',
				'selector' => '{{WRAPPER}} .breadcrumb a, .breadcrumb span.current, .breadcrumb',
			]
		);

        $this->add_control(
            'breadcrumb_color',
            [
                'label' => __('BreadCrumb Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .breadcrumb a' => 'color: {{VALUE}}',
				],
            ]
        );

        $this->add_control(
            'breadcrumb_current_page_color',
            [
                'label' => __('Current Page Color', 'levert-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .breadcrumb span.current' => 'color: {{VALUE}}',
				],
            ]
        );

        

        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
            'post_style',
            [
                'label' => __('Style', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_title_typography',
				'selector' => '{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button',
			]
		);

        $this->add_control(
			'accordion_title_color',
			[
				'label' => esc_html__( 'Title Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'accordion_title_border_color',
			[
				'label' => esc_html__( 'Title Border Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'accordion_title_background_color',
			[
				'label' => esc_html__( 'Title Background Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'accordion_title_border_color',
			[
				'label' => esc_html__( 'Title Border Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'accordion_content_typography',
				'selector' => '{{WRAPPER}} .faq-accordion .accordion-item .accordion-collapse .accordion-body',
			]
		);

        $this->add_control(
			'accordion_content_color',
			[
				'label' => esc_html__( 'Content Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-collapse .accordion-body' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'accordion_content_background_color',
			[
				'label' => esc_html__( 'Content Background Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-collapse .accordion-body' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'accordion_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'levert-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion-item .accordion-header button:after, .faq-accordion .accordion-item .accordion-header button:before' => 'background-color: {{VALUE}}',
				],
			]
		);


        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        
        echo get_levert_breadcrumbs();
    }
}
