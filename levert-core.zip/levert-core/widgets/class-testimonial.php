<?php

namespace LevertElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */



class LevertTestimonial extends Widget_Base
{

    public function get_name()
    {
        return 'testimonial';
    }

    public function get_title()
    {
        return __('Testimonial', 'levert-core');
    }

    public function get_icon()
    {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories()
    {
        return ['levert-addons'];
    }
    protected function register_controls()
    {

        $this->start_controls_section(
            'testimonial_content_tab',
            [
                'label' => __('Testimonial', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'testimonial_badge',
            [
                'label' => esc_html__('Testimonial Badge', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'TESTIMONIAL',
                'show_label' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'testimonial_title',
            [
                'label' => esc_html__('Testimonial Title', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Recent Feedback',
                'show_label' => true,
                'label_block' => true,
            ]
        );
        
        $this->add_control(
            'testimonial_description',
            [
                'label' => esc_html__('Testimonial Description', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Trusted by more than 700 people',
                'show_label' => true,
                'label_block' => true,
            ]
        );


        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'author_name',
            [
                'label' => __('Author Name', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'show_label' => true,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_content',
            [
                'label' => __('Testimonial Content', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'show_label' => true,
            ]
        );

        $repeater->add_control(
            'author_image',
            [
                'label' => __('Choose Image', 'levert-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'default' => 'full',
                'separator' => 'none',
            ]
        );
        $repeater->add_control(
            'author_designation',
            [
                'label' => __('Designation', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
            ]
        );
        $repeater->add_control(
            'author_rating',
            [
                'label' => __('Rating', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '4.9',
                'label_block' => false,
                'show_label' => true,
            ]
        );
        $this->add_control(
            'testimonial_list',
            [
                'label' => __('Testimonial', 'levert-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'author_name' => __('Ben Stocks', 'levert-core'),
                        'testimonial_content' => __('Offering officers village what to concept it are expecting on. The so because theory policeman, question one and for western the being at a is as could her necessary associate', 'levert-core'),
                        'author_designation' => __('CEO, Founder', 'levert-core'),
                        'author_rating' => '5'
                    ],
                    [
                        'author_name' => __('David Warner', 'levert-core'),
                        'testimonial_content' => __('Make problem folks study pointed the pursuit experiments is a have distributors. He once blocks plan and they by or compensation client separated an pursuit the.', 'levert-core'),
                        'author_location' => __('Australia', 'levert-core'),
                        'author_designation' => __('Project Manager', 'levert-core'),
                        'author_rating' => '4.5'
                    ]
                ],
                'title_field' => '{{{ author_name }}}',
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'setting_section',
            [
                'label' => __('Slider Settings', 'plugin-name'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __('Loop?', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'levert-core'),
                'label_off' => __('No', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'arrows',
            [
                'label' => __('Show arrows?', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'levert-core'),
                'label_off' => __('Hide', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay?', 'levert-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'levert-core'),
                'label_off' => __('No', 'levert-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_time',
            [
                'label' => __('Autoplay Time', 'levert-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '1000',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
            'post_
              style',
            [
                'label' => __('Style', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );




        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $testimonial_id = rand(96, 9450986);

        echo ' 
        <div class="testimonial-area">
            <div class="testimonial-wrapper">
                <div class="section-title my-3">
                    <span class="badge mb-2">'.esc_html($settings['testimonial_badge']).'</span>
                    <h2 class="display-3 mb-2">'.esc_html($settings['testimonial_title']).'</h2>
                    <p>'.esc_html($settings['testimonial_description']).'</p>
                </div>';
                if ($settings['arrows'] == 'yes') {
                    echo '<div class="testimonial-arrow">
                        <div class="swiper-button-prev-l"></div>
                        <div class="swiper-button-next-r"></div>
                    </div>';
                }
            echo '</div>
          <div class="testimonial-container">
            <div class="swiper-container testimonial-slider-' . $testimonial_id . '">
                <div class="swiper-wrapper">';
            if (is_array($settings['testimonial_list'])) :
                foreach ($settings['testimonial_list'] as $testimonial) {

                    echo '<div class="swiper-slide">
                        <div class="testimonial-box" data-aos="fade-up">
                            <div class="author-info mb-3">
                                <img src="' . esc_url($testimonial['author_image']['url']) . '" alt="' . esc_attr($testimonial['author_name']) . '">
                                <div class="author-content">
                                    <h4 class="m-0">' . esc_html($testimonial['author_name']) . '</h4>
                                    <span class="small">' . esc_html($testimonial['author_designation']) . '</span>
                                </div>
                            </div>
                            <div class="testimonial-content">
                                <p>' . esc_html($testimonial['testimonial_content']) . '</p>
                    
                                <div class="review-rating">
                                    <div class="star-ratings">
                                        <div class="Stars" style="--rating: ' . esc_html($testimonial['author_rating']) . ';" aria-label="Rating of this product is 2.3 out of 5.">
                                        </div>
                                    </div>
                    
                    
                                </div>
                            </div>
                        </div>
                    </div>';
                }
            endif;
            echo '
               </div>
            </div>
          </div>
        </div>
          ';


        if (count($settings['testimonial_list']) > 1) {

            if ($settings['arrows'] == 'yes') {
                $arrows = 'true';
            } else {
                $arrows = 'false';
            }
            if ($settings['autoplay'] == 'yes') {
                $autoplay = 'true';
            } else {
                $autoplay = 'false';
            }
            if ($settings['loop'] == 'yes') {
                $loop = 'true';
            } else {
                $loop = 'false';
            }

            echo '<script>

		var swiper = new Swiper(".testimonial-slider-' . $testimonial_id . '", {
		slidesPerView: 3,
		spaceBetween: 24,';
            if ($autoplay == 'true') {
                echo 'speed: ' . $settings['autoplay_time'] . ',';
            }
            echo ' 
		autoplay:' . $autoplay . ', 
		loop:' . $loop . ', 
		loopedSlides: 50,
		
		navigation: {
			nextEl: ".swiper-button-next-r",
			prevEl: ".swiper-button-prev-l",
		}, 
		breakpoints: {
			0: {
			slidesPerView: 1,
			}, 
			700: {
			slidesPerView: 2,
			}, 
			991: {
			slidesPerView: 2,
			},
			1420: {
			slidesPerView: 2,  
			}
		}
		});

    </script>';
        }
    }
}
