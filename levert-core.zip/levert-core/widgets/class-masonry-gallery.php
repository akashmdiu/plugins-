<?php

namespace LevertElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */


class MasonryGallery extends Widget_Base
{

    public function get_name()
    {
        return 'masonry-gallery';
    }

    public function get_title()
    {
        return __('Masonry Gallery', 'levert-core');
    }

    public function get_icon()
    {
        return 'eicon-gallery-masonry';
    }

    public function get_categories()
    {
        return ['levert-addons'];
    }
    protected function register_controls()
    {

        //Content Tab

        $this->start_controls_section(
            'masonry_gallery_content',
            [
                'label' => __('Masonry Gallery', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'masonry_gallery',
            [
                'label' => esc_html__('Add Images', 'levert-core'),
                'type' => \Elementor\Controls_Manager::GALLERY,
                'default' => [],
            ]
        );

        $this->end_controls_section();


        //Style Tab
        $this->start_controls_section(
            'member_style',
            [
                'label' => __('Style', 'levert-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display(); ?>
             <div class="row" data-masonry='{"percentPosition": true }'>
                 <?php 
                  if(is_array($settings['masonry_gallery'])){
                    foreach ($settings['masonry_gallery'] as $image) {
                        echo '
                        <div class="col-md-4">
                                <div class="gallery-box mt-3" data-aos="fade">
                                    <img src="'.esc_url($image['url']).'" alt="'.esc_attr( 'gallary-image' ).'">
                                    <a href="'.esc_url($image['url']).'" class="gallery-plus">
                                        <img src="https://d33wubrfki0l68.cloudfront.net/3e884397e448ed6361477ca7306f1d080d2f9f0f/516f9/assets/images/gallery-plus.svg" alt="'.esc_attr( 'gallary-plus-icon' ).'" />        
                                    </a>
                                </div>
                            </div>
                        ';
                    }
                }
                 ?>
             </div>
        <?php
    }
}
