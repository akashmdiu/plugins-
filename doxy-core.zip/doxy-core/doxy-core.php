<?php
/**
 * @package ThemeixPlugins
 */
/*
Plugin Name: Doxy Core
Plugin URI: https://themeix.com/plugins/doxy-core
Description: This is plugin use for Themeix Doxy WordPress theme.
Version: 2.0.0
Author: Themeix
Author URI: https://themeix.com/
License: GPLv2 or later
Text Domain: doxy-core
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/

if(!defined('ABSPATH')){
    die;
}

class ThemeixDoxyPlugin{
    function add_action_hook(){
        add_action('init', array($this, 'doxy_cpt'));
        add_shortcode('social_share_buttons', array($this, 'doxy_social_sharing_buttons'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    //activation
    function activation(){
        //generated CPT
       // $this->doxy_cpt();
        
        //generated social share buttons
        $this->doxy_social_sharing_buttons();
        
        //flush rewrite rules
        flush_rewrite_rules();
    }

    //Deactivation
    function deactivation(){

    }

    function enqueue_scripts(){
        //enquqe main stylesheet
        wp_enqueue_style('themeix-main', plugins_url('assets/themeix.main.css', __FILE__));
    }

    //Custom Post Type
   
    function doxy_cpt(){
        //Register Docs Post
        $labels = array(
		'name'                  => _x( 'docs', 'Post Type General Name', 'doxy-core' ),
		'singular_name'         => _x( 'Docs', 'Post Type Singular Name', 'doxy-core' ),
		'menu_name'             => __( 'Docs', 'doxy-core' ),
		'name_admin_bar'        => __( 'Doc', 'doxy-core' ),
		'archives'              => __( 'Docs Archives', 'doxy-core' ),
		'attributes'            => __( 'Docs Attributes', 'doxy-core' ),
		'parent_item_colon'     => __( 'Parent Docs:', 'doxy-core' ),
		'all_items'             => __( 'All Docs', 'doxy-core' ),
		'add_new_item'          => __( 'Add New Docs', 'doxy-core' ),
		'add_new'               => __( 'Add New', 'doxy-core' ),
		'new_item'              => __( 'New Item', 'doxy-core' ),
		'edit_item'             => __( 'Edit Docs', 'doxy-core' ),
		'update_item'           => __( 'Update Docs', 'doxy-core' ),
		'view_item'             => __( 'View Docs', 'doxy-core' ),
		'view_items'            => __( 'View Docs', 'doxy-core' ),
		'search_items'          => __( 'Search Docs', 'doxy-core' ),
		'not_found'             => __( 'Not found', 'doxy-core' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'doxy-core' ),
		'featured_image'        => __( 'Featured Image', 'doxy-core' ),
		'set_featured_image'    => __( 'Set featured image', 'doxy-core' ),
		'remove_featured_image' => __( 'Remove featured image', 'doxy-core' ),
		'use_featured_image'    => __( 'Use as featured image', 'doxy-core' ),
		'insert_into_item'      => __( 'Insert into item', 'doxy-core' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'doxy-core' ),
		'items_list'            => __( 'Items list', 'doxy-core' ),
		'items_list_navigation' => __( 'Items list navigation', 'doxy-core' ),
		'filter_items_list'     => __( 'Filter items list', 'doxy-core' ),
	);
	$args = array(
		'label'                 => __( 'Docs', 'doxy-core' ),
		'description'           => __( 'Post Type Description', 'doxy-core' ),
		'labels'                => $labels,
         'supports' => array( 'title', 'author', 'thumbnail', 'editor', 'revisions', 'page-attributes', 'custom-fields' ),
    		
    		'hierarchical'          => true,
    		'public'                => true,
    		'show_ui'               => true,
    		'show_in_menu'          => true,
    		'menu_position'         => 5,
    		'show_in_admin_bar'     => true,
    		'show_in_nav_menus'     => true,
    		'can_export'            => true,
    		'has_archive'           => true,
    		'exclude_from_search'   => false,
    		'publicly_queryable'    => true,
    		'show_in_rest' => true,
    		'capability_type'       => 'page',
    		'menu_icon' => 'dashicons-media-document',
    	);
    	register_post_type( 'docs', $args );
    	
    	$labels = array(
    		'name'              => _x( 'Docs Name', 'doxy-core' ),
    		'singular_name'     => _x( 'Doc Name', 'doxy-core' ),
    		'search_items'      => __( 'Search Docs Name', 'doxy-core' ),
    		'all_items'         => __( 'All Docs Name', 'doxy-core' ),
    		'parent_item'       => __( 'Parent Docs Name', 'doxy-core' ),
    		'parent_item_colon' => __( 'Parent Docs Name:', 'doxy-core' ),
    		'edit_item'         => __( 'Edit Docs Name', 'doxy-core' ),
    		'update_item'       => __( 'Update Docs Name', 'doxy-core' ),
    		'add_new_item'      => __( 'Add New Docs Name', 'doxy-core' ),
    		'new_item_name'     => __( 'New Docs Name', 'doxy-core' ),
    		'menu_name'         => __( 'Docs Name', 'doxy-core' ),
	    );
    
    	$args = array(
    		'hierarchical'      => true,
    		'labels'            => $labels,
    		'show_ui'           => true,
    		'show_admin_column' => true,
    		'query_var'         => true,
    		'rewrite'           => array( 'slug' => 'doc-category' ),
    	);
    
    	register_taxonomy( 'doc-category', array( 'docs' ), $args );
        
        
    }
    //Doxy Social Share Buttons
     function doxy_social_sharing_buttons() {
        if(is_singular()){
        
            // Get current post URL 
            $Post_url = get_the_permalink();
     
            // Get current post title
            $post_title = get_the_title();
     
            // Construct sharing URL without using any script
            $twitterURL = 'https://twitter.com/intent/tweet?text='.$post_title.'&amp;url='.$Post_url.'&amp;via=doxy';
            $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$Post_url;
            $googleURL = 'https://plus.google.com/share?url='.$Post_url;
            $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$Post_url.'&amp;title='.$post_title;
     
        ?>
            <ul class="single-share list-inline float-right">
                <li class="list-inline-item"><?php _e('Share:', 'doxy-core');?></li>
                <li><a href="<?php echo esc_url($facebookURL); ?>" onclick="javascript:window.open(this.href, 'facebook-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"  class="blue"><i class="fa fa-facebook-f"></i></a></li>

                <li><a href="<?php echo esc_url($twitterURL); ?>" onclick="javascript:window.open(this.href, 'facebook-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" class="paste"><i class="fa fa-twitter"></i></a></li>

                <li><a href="<?php echo esc_url($googleURL); ?>" onclick="javascript:window.open(this.href, 'facebook-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" class="red"><i class="fa fa-google-plus"></i></a></li>
                
                <li><a href="<?php echo esc_url($linkedInURL); ?>" onclick="javascript:window.open(this.href, 'facebook-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" class="pink"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
        <?php
            
          
        }
    }
}
if(class_exists('ThemeixDoxyPlugin')){
    $doxyPlugin = new ThemeixDoxyPlugin();
    $doxyPlugin->add_action_hook();
}


//Activation Hook
register_activation_hook(__FILE__, array($doxyPlugin, 'activation'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($doxyPlugin, 'deactivation'));