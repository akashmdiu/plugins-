<?php

/**
 * @package ThemeixPlugins
 */
/*
Plugin Name: Churel Core
Plugin URI: https://themeix.com/plugins/churel-core
Description: This is plugin use for Themeix Churel WordPress theme.
Version: 1.0.0
Author: Themeix
Author URI: https://themeix.com/
License: GPLv2 or later 
Text Domain: churel-core
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/

if (!defined('ABSPATH')) {
	die;
}

class ThemeixChurelPlugin
{
	function add_action_hook()
	{
		add_shortcode('social_share', array($this, 'churel_social_sharing_buttons'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
	}

	//activation
	function activation()
	{

		//generated social share buttons
		$this->churel_social_sharing_buttons();

		//flush rewrite rules
		flush_rewrite_rules();
	}

	//Deactivation
	function deactivation()
	{ }

	function enqueue_scripts()
	{
		//enquqe main stylesheet
		wp_enqueue_style('trabajo-style', plugins_url('assets/main.css', __FILE__));
	}



	//trabajo Social Share Buttons
	function churel_social_sharing_buttons()
	{
		if (is_singular()) {

			// Get current post URL 
			$Post_url = get_the_permalink();

			// Get current post title
			$post_title = get_the_title();

			// Construct sharing URL without using any script
			$twitterURL = 'https://twitter.com/intent/tweet?text=' . $post_title . '&amp;url=' . $Post_url . '&amp;via=trabajo';
			$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $Post_url;
			$googleURL = 'https://plus.google.com/share?url=' . $Post_url;
			$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $Post_url . '&amp;title=' . $post_title;

			?>
			<ul class="social-fixed list-inline">
				<li><a class="facebook" href="<?php echo esc_url($facebookURL); ?>" onclick="javascript:window.open(this.href, 'facebook-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fab fa-facebook"></i></a></li>

				<li><a class="twitter" href="<?php echo esc_url($twitterURL); ?>" onclick="javascript:window.open(this.href, 'twitter-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fab fa-twitter"></i></a></li>

				<li><a class="instagram" href="<?php echo esc_url($linkedInURL); ?>" onclick="javascript:window.open(this.href, 'linkedin-share',  ' menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
			</ul>

<?php


		}
	}
}
if (class_exists('ThemeixChurelPlugin')) {
	$trabajoPlugin = new ThemeixChurelPlugin();
	$trabajoPlugin->add_action_hook();
}


//Activation Hook
register_activation_hook(__FILE__, array($trabajoPlugin, 'activation'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($trabajoPlugin, 'deactivation'));
