<?php

/**
 * @package ThemeixPlugins
 */
/*
Plugin Name: Churel Core
Plugin URI: https://themeix.com/plugins/churel-core
Description: This is plugin use for Themeix Churel WordPress theme.
Version: 1.0.0
Author: Themeix
Author URI: https://themeix.com/
License: GPLv2 or later 
Text Domain: churel-core
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2021 Automattic, Inc.
*/

if (!defined('ABSPATH')) {
	die;
}

class ThemeixChurelPlugin
{
	function add_action_hook()
	{
		add_shortcode('social_share', array($this, 'churel_social_sharing_buttons'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

		add_action('show_user_profile', array($this, 'churel_extra_user_profile_fields'));
		add_action('edit_user_profile', array($this, 'churel_extra_user_profile_fields'));
		add_action('personal_options_update', array($this, 'churel_save_extra_user_profile_fields'));
		add_action('edit_user_profile_update', array($this, 'churel_save_extra_user_profile_fields'));
	}

	//activation
	function activation()
	{

		//generated social share buttons
		$this->churel_social_sharing_buttons();

		//flush rewrite rules
		flush_rewrite_rules();
	}

	//Deactivation
	function deactivation()
	{ }

	function enqueue_scripts()
	{
		//enquqe main stylesheet
		wp_enqueue_style('churel-style', plugins_url('assets/main.css', __FILE__));
	}



	//churel Social Share Buttons
	function churel_social_sharing_buttons()
	{
		if (is_singular()) {

			// Get current post URL 
			$Post_url = get_the_permalink();

			// Get current post title
			$post_title = get_the_title();

			// Construct sharing URL without using any script
			$twitterURL = 'https://twitter.com/intent/tweet?text=' . $post_title . '&amp;url=' . $Post_url . '&amp;via=churel';
			$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $Post_url;
			$googleURL = 'https://plus.google.com/share?url=' . $Post_url;
			$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $Post_url . '&amp;title=' . $post_title;

			?>
			<ul class="list-inline aos-init aos-animate" data-aos="fade-up" data-aos-duration="500">

				<li class="list-inline-item"><a class="facebook" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($facebookURL); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;" data-original-title="Facebook"><i class="fab fa-facebook-f"></i></a></li>

				<li class="list-inline-item"><a class="twitter" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($twitterURL); ?>" onclick="window.open(this.href, 'twitter-share','width=580,height=296');return false;" data-original-title="Twitter"><i class="fab fa-twitter"></i></a></li>

				<li class="list-inline-item"><a class="linkedin" onclick="window.open(this.href, 'linkedin-share','width=580,height=296');return false;" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($linkedInURL); ?>" data-original-title="LinkedIn"><i class="fab fa-linkedin"></i></a></li>

			</ul>

		<?php


				}
			}

			function churel_extra_user_profile_fields($user)
			{ ?>
		<h3><?php echo esc_html__('Extra profile information', 'churel'); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="facebook"><?php echo esc_html__('Facebook', 'churel'); ?></label></th>
				<td>
					<input type="text" name="facebook" id="facebook" value="<?php echo esc_attr(get_the_author_meta('facebook', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your facebook url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="twitter"><?php echo esc_html__('Twitter', 'churel'); ?></label></th>
				<td>
					<input type="text" name="twitter" id="twitter" value="<?php echo esc_attr(get_the_author_meta('twitter', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your twitter url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="instagram"><?php echo esc_html__('Instagram', 'churel'); ?></label></th>
				<td>
					<input type="text" name="instagram" id="instagram" value="<?php echo esc_attr(get_the_author_meta('instagram', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your instagram url.', 'churel'); ?></span>
				</td>
			</tr>
		</table>
<?php }

	function churel_save_extra_user_profile_fields($user_id)
	{
		if (!current_user_can('edit_user', $user_id)) {
			return false;
		}
		update_user_meta($user_id, 'facebook', $_POST['facebook']);
		update_user_meta($user_id, 'twitter', $_POST['twitter']);
		update_user_meta($user_id, 'instagram', $_POST['instagram']);
	}
}
if (class_exists('ThemeixChurelPlugin')) {
	$churelPlugin = new ThemeixChurelPlugin();
	$churelPlugin->add_action_hook();
}


//Activation Hook
register_activation_hook(__FILE__, array($churelPlugin, 'activation'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($churelPlugin, 'deactivation'));
